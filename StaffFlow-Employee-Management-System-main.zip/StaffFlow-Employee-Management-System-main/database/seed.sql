-- ==========================================================
-- Employee Management System - Seed Data
-- Default Admin credentials:
-- Email: admin@staffflow.com  /  Username: admin  /  Password: admin123
-- ==========================================================

USE defaultdb;

-- Insert Default Admin User
-- Password is 'admin123' hashed with bcrypt ($2a$10$w8TkyXUeDqQo5oFomXz6QeV6/3vAODdNu5rT88f2Z3C7gT6w5Lwre)
INSERT INTO users (id, username, email, password_hash, name, role) VALUES
(1, 'admin', 'admin@staffflow.com', '$2a$10$w8TkyXUeDqQo5oFomXz6QeV6/3vAODdNu5rT88f2Z3C7gT6w5Lwre', 'System Administrator', 'admin'),
(2, 'hrmanager', 'hr@staffflow.com', '$2a$10$w8TkyXUeDqQo5oFomXz6QeV6/3vAODdNu5rT88f2Z3C7gT6w5Lwre', 'Sarah Jenkins', 'hr_manager')
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Insert Departments
INSERT INTO departments (id, name, description, manager_name, budget) VALUES
(1, 'Engineering', 'Software development, infrastructure, and technical architecture.', 'Alex Chen', 650000.00),
(2, 'Human Resources', 'Talent acquisition, employee welfare, compensation, and onboarding.', 'Sarah Jenkins', 180000.00),
(3, 'Product Management', 'Product vision, feature roadmaps, analytics, and UX research.', 'Marcus Brody', 290000.00),
(4, 'Marketing & Sales', 'Brand strategy, enterprise sales, content marketing, and growth.', 'Elena Rostova', 340000.00),
(5, 'Finance & Legal', 'Accounting, audit, financial planning, compliance, and governance.', 'David Kim', 210000.00),
(6, 'Customer Support', 'Client success, technical customer care, and satisfaction SLA.', 'Priya Sharma', 140000.00)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- Insert Sample Employees
INSERT INTO employees (id, employee_id, full_name, email, phone, gender, date_of_birth, department_id, designation, joining_date, salary, status, address) VALUES
(1, 'EMP-1001', 'Alexander Hayes', 'alexander.hayes@staffflow.com', '+1 (555) 234-5678', 'Male', '1988-04-14', 1, 'Principal Software Engineer', '2022-03-15', 135000.00, 'active', '742 Evergreen Terrace, Springfield, OR'),
(2, 'EMP-1002', 'Sophia Rodriguez', 'sophia.rodriguez@staffflow.com', '+1 (555) 345-6789', 'Female', '1992-09-21', 1, 'Senior Frontend Architect', '2022-06-01', 115000.00, 'active', '124 Conch Street, Pacific Grove, CA'),
(3, 'EMP-1003', 'Liam O\'Connor', 'liam.oconnor@staffflow.com', '+1 (555) 456-7890', 'Male', '1990-11-05', 1, 'DevOps & Cloud Engineer', '2023-01-10', 105000.00, 'active', '88 St. Marks Place, New York, NY'),
(4, 'EMP-1004', 'Emily Watson', 'emily.watson@staffflow.com', '+1 (555) 567-8901', 'Female', '1994-02-18', 3, 'Lead Product Manager', '2022-08-20', 120000.00, 'active', '452 Pine Valley Rd, Austin, TX'),
(5, 'EMP-1005', 'Marcus Vance', 'marcus.vance@staffflow.com', '+1 (555) 678-9012', 'Male', '1987-07-30', 2, 'Senior Talent Acquisition Lead', '2021-11-01', 88000.00, 'active', '303 Lincoln Way, Chicago, IL'),
(6, 'EMP-1006', 'Aria Tanaka', 'aria.tanaka@staffflow.com', '+1 (555) 789-0123', 'Female', '1995-12-08', 4, 'Enterprise Account Executive', '2023-04-12', 95000.00, 'active', '910 Market Street, San Francisco, CA'),
(7, 'EMP-1007', 'Nathanial Drake', 'nathanial.drake@staffflow.com', '+1 (555) 890-1234', 'Male', '1991-03-27', 4, 'Growth Marketing Director', '2022-02-15', 110000.00, 'active', '1802 Grand Ave, Seattle, WA'),
(8, 'EMP-1008', 'Fatima Al-Mansoor', 'fatima.almansoor@staffflow.com', '+1 (555) 901-2345', 'Female', '1989-08-16', 5, 'Senior Financial Controller', '2021-09-01', 118000.00, 'active', '65 Commonwealth Ave, Boston, MA'),
(9, 'EMP-1009', 'Jackson Reid', 'jackson.reid@staffflow.com', '+1 (555) 012-3456', 'Male', '1996-05-19', 1, 'Full Stack Engineer', '2023-09-01', 92000.00, 'active', '521 Boulder St, Denver, CO'),
(10, 'EMP-1010', 'Chloe Bennett', 'chloe.bennett@staffflow.com', '+1 (555) 123-4560', 'Female', '1993-10-12', 6, 'Customer Success Manager', '2023-02-28', 78000.00, 'active', '44 Peachtree St, Atlanta, GA'),
(11, 'EMP-1011', 'Devon Miller', 'devon.miller@staffflow.com', '+1 (555) 234-5671', 'Male', '1997-01-24', 6, 'Technical Support Specialist', '2024-01-15', 62000.00, 'inactive', '710 Broadway, Nashville, TN'),
(12, 'EMP-1012', 'Hannah Zimmerman', 'hannah.zimmerman@staffflow.com', '+1 (555) 345-6782', 'Female', '1991-06-30', 3, 'Senior UX/UI Designer', '2023-07-10', 98000.00, 'on_leave', '110 Ocean Drive, Miami, FL')
ON DUPLICATE KEY UPDATE full_name=VALUES(full_name);
