import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  ArrowLeft,
  Edit3,
  Trash2,
  Mail,
  Phone,
  Calendar,
  Building2,
  Briefcase,
  DollarSign,
  MapPin,
  BadgeCheck,
  User,
  Clock,
  ShieldAlert
} from 'lucide-react';
import { employeeApi, departmentApi } from '../services/clientServices.ts';
import { Employee, Department } from '../types/index.ts';
import { formatCurrency, formatDate } from '../utils/formatters.ts';
import { useToast } from '../context/ToastContext.tsx';
import { EmployeeModal } from '../components/EmployeeModal.tsx';
import { DeleteConfirmModal } from '../components/DeleteConfirmModal.tsx';

export const EmployeeDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { success, error } = useToast();

  const [employee, setEmployee] = useState<Employee | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    departmentApi.list().then(setDepartments).catch(() => {});
  }, []);

  const fetchEmployee = async () => {
    if (!id) return;
    try {
      setIsLoading(true);
      const data = await employeeApi.getById(id);
      setEmployee(data);
    } catch {
      error('Employee profile not found');
      navigate('/employees');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployee();
  }, [id]);

  const handleUpdate = async (formData: any) => {
    if (!employee) return;
    try {
      setIsSubmitting(true);
      const updated = await employeeApi.update(employee.id, formData);
      setEmployee(updated);
      setIsEditModalOpen(false);
      success('Employee profile updated successfully.');
    } catch (err: any) {
      error(err.response?.data?.error || 'Failed to update employee');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!employee) return;
    try {
      setIsSubmitting(true);
      await employeeApi.delete(employee.id);
      success(`Employee "${employee.full_name}" has been removed.`);
      navigate('/employees');
    } catch (err: any) {
      error(err.response?.data?.error || 'Failed to delete employee');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="py-20 text-center">
        <div className="inline-flex items-center gap-3 text-slate-500 font-medium">
          <span className="w-6 h-6 border-2 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin" />
          <span>Loading employee profile...</span>
        </div>
      </div>
    );
  }

  if (!employee) return null;

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Back button */}
      <div>
        <Link
          to="/employees"
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-indigo-600 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Employee Directory</span>
        </Link>
      </div>

      {/* Profile Header Hero Card */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-500 text-white font-bold text-2xl flex items-center justify-center shadow-lg shadow-indigo-600/25">
            {employee.full_name.charAt(0)}
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              <h1 className="text-2xl font-bold tracking-tight text-slate-900">{employee.full_name}</h1>
              <span className="font-mono text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-200/60 px-2 py-0.5 rounded-md">
                {employee.employee_id}
              </span>
              <span
                className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                  employee.status === 'active'
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : employee.status === 'on_leave'
                    ? 'bg-amber-50 text-amber-700 border border-amber-200'
                    : 'bg-slate-100 text-slate-700 border border-slate-200'
                }`}
              >
                <span
                  className={`w-1.5 h-1.5 rounded-full ${
                    employee.status === 'active'
                      ? 'bg-emerald-500'
                      : employee.status === 'on_leave'
                      ? 'bg-amber-500'
                      : 'bg-slate-400'
                  }`}
                />
                <span className="capitalize">{employee.status.replace('_', ' ')}</span>
              </span>
            </div>
            <p className="text-sm font-semibold text-slate-700 mt-1">
              {employee.designation} • <span className="text-indigo-600 font-medium">{employee.department_name}</span>
            </p>
            <p className="text-xs text-slate-500 mt-0.5">
              Member since {formatDate(employee.joining_date)}
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/20 transition-all"
          >
            <Edit3 className="w-4 h-4" />
            <span>Edit Profile</span>
          </button>
          <button
            onClick={() => setIsDeleteModalOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-200 text-slate-700 hover:text-rose-600 font-semibold text-xs sm:text-sm transition-all"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete</span>
          </button>
        </div>
      </div>

      {/* Profile Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Job & Employment Details */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 text-slate-900 font-bold text-sm">
            <Briefcase className="w-4 h-4 text-indigo-600" />
            <span>Employment & Role</span>
          </div>
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Department</span>
              <span className="font-semibold text-slate-900">{employee.department_name}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Designation / Title</span>
              <span className="font-semibold text-slate-900">{employee.designation}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Official Employee ID</span>
              <span className="font-mono font-semibold text-slate-900">{employee.employee_id}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Joining Date</span>
              <span className="font-semibold text-slate-900">{formatDate(employee.joining_date)}</span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500 font-medium">Current Status</span>
              <span className="capitalize font-semibold text-slate-900">{employee.status.replace('_', ' ')}</span>
            </div>
          </div>
        </div>

        {/* Card 2: Compensation & Payroll */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 text-slate-900 font-bold text-sm">
            <DollarSign className="w-4 h-4 text-emerald-600" />
            <span>Compensation & Payroll</span>
          </div>
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Annual Base Salary</span>
              <span className="font-mono font-bold text-sm text-slate-900">
                {formatCurrency(employee.salary)}
              </span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Estimated Monthly Gross</span>
              <span className="font-mono font-semibold text-slate-700">
                {formatCurrency(Math.round(employee.salary / 12))}
              </span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Payroll Frequency</span>
              <span className="font-semibold text-slate-900">Bi-Weekly</span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500 font-medium">Performance Review Cycle</span>
              <span className="font-semibold text-slate-900">Annual (Q4)</span>
            </div>
          </div>
        </div>

        {/* Card 3: Personal Information */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 text-slate-900 font-bold text-sm">
            <User className="w-4 h-4 text-indigo-600" />
            <span>Personal Information</span>
          </div>
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Full Legal Name</span>
              <span className="font-semibold text-slate-900">{employee.full_name}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Gender</span>
              <span className="font-semibold text-slate-900">{employee.gender}</span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500 font-medium">Date of Birth</span>
              <span className="font-semibold text-slate-900">{formatDate(employee.date_of_birth)}</span>
            </div>
          </div>
        </div>

        {/* Card 4: Contact & Residence */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 text-slate-900 font-bold text-sm">
            <MapPin className="w-4 h-4 text-indigo-600" />
            <span>Contact & Residential Address</span>
          </div>
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Primary Email</span>
              <a
                href={`mailto:${employee.email}`}
                className="font-semibold text-indigo-600 hover:underline"
              >
                {employee.email}
              </a>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-slate-50">
              <span className="text-slate-500 font-medium">Contact Phone</span>
              <a
                href={`tel:${employee.phone}`}
                className="font-semibold text-slate-900 hover:text-indigo-600"
              >
                {employee.phone}
              </a>
            </div>
            <div className="py-1">
              <span className="text-slate-500 font-medium block mb-1">Residential Address</span>
              <p className="text-slate-800 leading-relaxed font-medium">
                {employee.address || 'No residential address on file.'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Modal */}
      <EmployeeModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSubmit={handleUpdate}
        employee={employee}
        departments={departments}
        isLoading={isSubmitting}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        title="Delete Employee Record"
        itemName={employee.full_name}
        itemDescription={`Employee ID: ${employee.employee_id} • ${employee.designation}`}
        isLoading={isSubmitting}
        onConfirm={handleDelete}
        onClose={() => setIsDeleteModalOpen(false)}
      />
    </div>
  );
};
