import React, { useState } from 'react';
import {
  FileCode2,
  Download,
  Play,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Shield,
  Layers,
  Server,
  Code
} from 'lucide-react';
import { testApi } from '../services/clientServices.ts';
import { useToast } from '../context/ToastContext.tsx';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
  durationMs: number;
}

export const ApiDocsPage: React.FC = () => {
  const { success, error } = useToast();
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [testResults, setTestResults] = useState<{
    results: TestResult[];
    summary: { total: number; passed: number; failed: number };
  } | null>(null);

  const handleRunTests = async () => {
    try {
      setIsRunningTests(true);
      const data = await testApi.runTests();
      setTestResults(data);
      if (data.summary.failed === 0) {
        success(`All ${data.summary.total} automated backend tests passed!`);
      } else {
        error(`${data.summary.failed} tests failed.`);
      }
    } catch {
      error('Failed to execute automated test runner');
    } finally {
      setIsRunningTests(false);
    }
  };

  const handleDownloadPostman = () => {
    // Generate download link for the postman collection
    const link = document.createElement('a');
    link.href = '/postman/Employee_Management_System.postman_collection.json';
    link.download = 'Employee_Management_System.postman_collection.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    success('Postman collection downloaded. Ready to import in Postman!');
  };

  const endpoints = [
    {
      group: 'Authentication',
      items: [
        { method: 'POST', path: '/api/auth/login', desc: 'Authenticate administrator/HR with email & password, returns JWT', auth: 'Public' },
        { method: 'POST', path: '/api/auth/logout', desc: 'Invalidate current session on client', auth: 'Public' },
        { method: 'GET', path: '/api/auth/profile', desc: 'Retrieve authenticated user identity and role', auth: 'Bearer JWT' },
      ],
    },
    {
      group: 'Employees (CRUD & Search)',
      items: [
        { method: 'GET', path: '/api/employees', desc: 'Paginated list with search, department_id, status, and sorting', auth: 'Bearer JWT' },
        { method: 'GET', path: '/api/employees/:id', desc: 'Fetch detailed employee record by primary key', auth: 'Bearer JWT' },
        { method: 'POST', path: '/api/employees', desc: 'Create new employee with auto-assigned EMP-ID', auth: 'Admin / HR' },
        { method: 'PUT', path: '/api/employees/:id', desc: 'Update employee designation, department, salary, or status', auth: 'Admin / HR' },
        { method: 'DELETE', path: '/api/employees/:id', desc: 'Permanently remove employee record from database', auth: 'Admin Only' },
      ],
    },
    {
      group: 'Departments',
      items: [
        { method: 'GET', path: '/api/departments', desc: 'List all departments with live headcount counts', auth: 'Bearer JWT' },
        { method: 'GET', path: '/api/departments/:id', desc: 'Get department and its assigned staff members', auth: 'Bearer JWT' },
        { method: 'POST', path: '/api/departments', desc: 'Create department with budget and manager', auth: 'Admin / HR' },
        { method: 'PUT', path: '/api/departments/:id', desc: 'Update department metadata and budget', auth: 'Admin / HR' },
        { method: 'DELETE', path: '/api/departments/:id', desc: 'Delete department (enforces 0 assigned employees constraint)', auth: 'Admin Only' },
      ],
    },
    {
      group: 'Dashboard & Telemetry',
      items: [
        { method: 'GET', path: '/api/dashboard/stats', desc: 'Workforce KPIs, department distribution & joining trends', auth: 'Bearer JWT' },
        { method: 'POST', path: '/api/dashboard/reset', desc: 'Restore database to initial factory seed dataset', auth: 'Admin Only' },
      ],
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">API Documentation & Testing</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            OpenAPI 3.0 specification, Postman collection exports, and automated integration test runner.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleDownloadPostman}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 border border-indigo-200/60 text-indigo-700 font-semibold text-xs sm:text-sm transition-all"
          >
            <Download className="w-4 h-4 text-indigo-600" />
            <span>Download Postman Collection</span>
          </button>
          <a
            href="/api/docs"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold text-xs sm:text-sm transition-all"
          >
            <ExternalLink className="w-4 h-4 text-slate-500" />
            <span>Native Swagger UI</span>
          </a>
        </div>
      </div>

      {/* Test Runner Hero Banner */}
      <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 text-white shadow-lg shadow-slate-950/20">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
              <Server className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-tight">Automated Backend Test Suite</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Executes unit, authentication, relation constraints, and CRUD integration tests against the live database.
              </p>
            </div>
          </div>
          <button
            onClick={handleRunTests}
            disabled={isRunningTests}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 shrink-0 disabled:opacity-50"
          >
            <Play className={`w-4 h-4 ${isRunningTests ? 'animate-spin' : ''}`} />
            <span>{isRunningTests ? 'Running Test Suite...' : 'Run Automated Tests'}</span>
          </button>
        </div>

        {/* Live Test Results Output */}
        {testResults && (
          <div className="mt-6 pt-6 border-t border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-300">
                Execution Results: {testResults.summary.passed}/{testResults.summary.total} Passed
              </span>
              <span
                className={`font-bold px-2 py-0.5 rounded ${
                  testResults.summary.failed === 0
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-rose-500/20 text-rose-400'
                }`}
              >
                {testResults.summary.failed === 0 ? 'ALL CHECKS PASSED' : `${testResults.summary.failed} FAILED`}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-2">
              {testResults.results.map((res, i) => (
                <div
                  key={i}
                  className={`p-3 rounded-xl border flex items-start gap-3 ${
                    res.passed
                      ? 'bg-slate-800/60 border-slate-700/60'
                      : 'bg-rose-950/40 border-rose-800/60'
                  }`}
                >
                  {res.passed ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <div className="min-w-0 flex-1 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200">[{res.suite}]</span>
                      <span className="text-[10px] text-slate-400 font-mono">{res.durationMs}ms</span>
                    </div>
                    <p className="text-slate-300 mt-0.5 leading-relaxed">{res.name}</p>
                    {res.error && <p className="text-rose-400 mt-1 font-mono text-[11px]">{res.error}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Endpoint Reference Table */}
      <div className="space-y-6">
        {endpoints.map((group) => (
          <div key={group.group} className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="px-6 py-3.5 bg-slate-50/80 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-900">{group.group}</h2>
              <span className="text-xs text-slate-500">{group.items.length} Endpoints</span>
            </div>
            <div className="divide-y divide-slate-100">
              {group.items.map((item, idx) => (
                <div key={idx} className="p-4 sm:px-6 hover:bg-slate-50/50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span
                      className={`px-2.5 py-1 rounded-lg font-mono text-xs font-bold uppercase tracking-wide shrink-0 ${
                        item.method === 'GET'
                          ? 'bg-sky-50 text-sky-700 border border-sky-200'
                          : item.method === 'POST'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : item.method === 'PUT'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}
                    >
                      {item.method}
                    </span>
                    <span className="font-mono text-xs font-semibold text-slate-900">{item.path}</span>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 text-xs">
                    <span className="text-slate-600 text-left sm:text-right">{item.desc}</span>
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-semibold text-[11px] shrink-0">
                      {item.auth}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
