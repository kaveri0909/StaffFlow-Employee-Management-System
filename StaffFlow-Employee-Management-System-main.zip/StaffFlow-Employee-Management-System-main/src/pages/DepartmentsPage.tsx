import React, { useEffect, useState } from 'react';
import {
  Building2,
  Plus,
  Users,
  DollarSign,
  User,
  Edit3,
  Trash2,
  RefreshCw,
  ExternalLink
} from 'lucide-react';
import { departmentApi } from '../services/clientServices.ts';
import { Department, Employee } from '../types/index.ts';
import { formatCurrency } from '../utils/formatters.ts';
import { useToast } from '../context/ToastContext.tsx';
import { DepartmentModal } from '../components/DepartmentModal.tsx';
import { DepartmentEmployeesModal } from '../components/DepartmentEmployeesModal.tsx';
import { DeleteConfirmModal } from '../components/DeleteConfirmModal.tsx';

export const DepartmentsPage: React.FC = () => {
  const { success, error } = useToast();

  const [departments, setDepartments] = useState<Department[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Modals state
  const [isDepartmentModalOpen, setIsDepartmentModalOpen] = useState(false);
  const [editingDepartment, setEditingDepartment] = useState<Department | null>(null);
  const [deletingDepartment, setDeletingDepartment] = useState<Department | null>(null);
  const [viewingDepartment, setViewingDepartment] = useState<(Department & { employees?: Employee[] }) | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchDepartments = async () => {
    try {
      setIsLoading(true);
      const data = await departmentApi.list();
      setDepartments(data);
    } catch {
      error('Failed to load departments');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDepartments();
  }, []);

  const handleOpenCreate = () => {
    setEditingDepartment(null);
    setIsDepartmentModalOpen(true);
  };

  const handleOpenEdit = (dept: Department) => {
    setEditingDepartment(dept);
    setIsDepartmentModalOpen(true);
  };

  const handleViewEmployees = async (dept: Department) => {
    try {
      const detailed = await departmentApi.getById(dept.id);
      setViewingDepartment(detailed);
    } catch {
      error('Failed to retrieve department members');
    }
  };

  const handleSaveDepartment = async (formData: any) => {
    try {
      setIsSubmitting(true);
      if (editingDepartment) {
        await departmentApi.update(editingDepartment.id, formData);
        success(`Department "${formData.name}" updated successfully.`);
      } else {
        await departmentApi.create(formData);
        success(`Department "${formData.name}" created.`);
      }
      setIsDepartmentModalOpen(false);
      setEditingDepartment(null);
      fetchDepartments();
    } catch (err: any) {
      error(err.response?.data?.error || 'Failed to save department');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingDepartment) return;
    try {
      setIsSubmitting(true);
      await departmentApi.delete(deletingDepartment.id);
      success(`Department "${deletingDepartment.name}" deleted.`);
      setDeletingDepartment(null);
      fetchDepartments();
    } catch (err: any) {
      error(err.response?.data?.error || 'Failed to delete department');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Title & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Department Management</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Organizational structure, allocated budgets, leadership, and team assignments.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchDepartments}
            title="Refresh departments"
            className="p-2 text-slate-600 hover:text-indigo-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition-colors"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={handleOpenCreate}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Department</span>
          </button>
        </div>
      </div>

      {/* Departments Grid */}
      {isLoading ? (
        <div className="py-20 text-center">
          <div className="inline-flex items-center gap-3 text-slate-500 font-medium">
            <span className="w-6 h-6 border-2 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin" />
            <span>Loading departments...</span>
          </div>
        </div>
      ) : departments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-500">
          <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800">No departments found</h3>
          <p className="text-xs text-slate-500 mt-1">
            Create your first department to start structuring your team.
          </p>
          <button
            onClick={handleOpenCreate}
            className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold"
          >
            <Plus className="w-4 h-4" />
            <span>Create Department</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {departments.map((dept) => (
            <div
              key={dept.id}
              className="bg-white rounded-2xl border border-slate-200/80 shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between p-5"
            >
              <div>
                <div className="flex items-start justify-between gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(dept)}
                      title="Edit Department"
                      className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setDeletingDepartment(dept)}
                      title="Delete Department"
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="mt-3.5">
                  <h3 className="font-bold text-base text-slate-900 tracking-tight">{dept.name}</h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                    {dept.description || 'No specific description provided for this unit.'}
                  </p>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-100 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-600">
                    <span className="flex items-center gap-1.5 text-slate-500">
                      <User className="w-3.5 h-3.5" />
                      <span>Manager</span>
                    </span>
                    <span className="font-semibold text-slate-900">{dept.manager_name || 'Unassigned'}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-600">
                    <span className="flex items-center gap-1.5 text-slate-500">
                      <DollarSign className="w-3.5 h-3.5" />
                      <span>Budget</span>
                    </span>
                    <span className="font-mono font-semibold text-slate-900">
                      {formatCurrency(dept.budget)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-slate-600">
                    <span className="flex items-center gap-1.5 text-slate-500">
                      <Users className="w-3.5 h-3.5" />
                      <span>Headcount</span>
                    </span>
                    <span className="font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-800 text-[11px]">
                      {dept.employee_count ?? 0} {dept.employee_count === 1 ? 'member' : 'members'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100">
                <button
                  onClick={() => handleViewEmployees(dept)}
                  className="w-full py-2 px-3 rounded-xl bg-slate-50 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>View Team Members ({dept.employee_count ?? 0})</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Department Modal */}
      <DepartmentModal
        isOpen={isDepartmentModalOpen}
        onClose={() => {
          setIsDepartmentModalOpen(false);
          setEditingDepartment(null);
        }}
        onSubmit={handleSaveDepartment}
        department={editingDepartment}
        isLoading={isSubmitting}
      />

      {/* View Employees in Department Modal */}
      <DepartmentEmployeesModal
        isOpen={!!viewingDepartment}
        onClose={() => setViewingDepartment(null)}
        department={viewingDepartment}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={!!deletingDepartment}
        title="Delete Department"
        itemName={deletingDepartment?.name || ''}
        itemDescription={`Allocated Budget: ${formatCurrency(deletingDepartment?.budget || 0)} • Assigned Members: ${deletingDepartment?.employee_count || 0}`}
        isLoading={isSubmitting}
        onConfirm={handleConfirmDelete}
        onClose={() => setDeletingDepartment(null)}
      />
    </div>
  );
};
