import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Search,
  UserPlus,
  Download,
  Filter,
  RefreshCw,
  Building2,
  Users
} from 'lucide-react';
import { EmployeeTable } from '../components/EmployeeTable.tsx';
import { EmployeeModal } from '../components/EmployeeModal.tsx';
import { DeleteConfirmModal } from '../components/DeleteConfirmModal.tsx';
import { Employee, Department, PaginationMeta } from '../types/index.ts';
import { employeeApi, departmentApi } from '../services/clientServices.ts';
import { useToast } from '../context/ToastContext.tsx';
import { exportToCSV } from '../utils/formatters.ts';

export const EmployeesPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const { success, error } = useToast();

  const [employees, setEmployees] = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [pagination, setPagination] = useState<PaginationMeta>({
    page: 1,
    limit: 10,
    total: 0,
    totalPages: 1,
    hasNextPage: false,
    hasPrevPage: false,
  });

  // Filter & Search states
  const [searchTerm, setSearchTerm] = useState(searchParams.get('search') || '');
  const [selectedDept, setSelectedDept] = useState(searchParams.get('department_id') || '');
  const [selectedStatus, setSelectedStatus] = useState(searchParams.get('status') || 'all');
  const [sortBy, setSortBy] = useState(searchParams.get('sortBy') || 'created_at');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>(
    (searchParams.get('sortOrder') as 'asc' | 'desc') || 'desc'
  );
  const [page, setPage] = useState(Number(searchParams.get('page') || 1));
  const [limit, setLimit] = useState(Number(searchParams.get('limit') || 10));

  const [isLoading, setIsLoading] = useState(true);

  // Modals state
  const [isEmployeeModalOpen, setIsEmployeeModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [deletingEmployee, setDeletingEmployee] = useState<Employee | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load departments once
  useEffect(() => {
    departmentApi
      .list()
      .then((depts) => setDepartments(depts))
      .catch((err) => console.error('Failed to load departments', err));
  }, []);

  // Check URL query parameters for action=new
  useEffect(() => {
    if (searchParams.get('action') === 'new') {
      setEditingEmployee(null);
      setIsEmployeeModalOpen(true);
      // clean param
      searchParams.delete('action');
      setSearchParams(searchParams, { replace: true });
    }
  }, [searchParams, setSearchParams]);

  const fetchEmployees = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await employeeApi.list({
        search: searchTerm || undefined,
        department_id: selectedDept ? Number(selectedDept) : undefined,
        status: selectedStatus !== 'all' ? selectedStatus : undefined,
        sortBy,
        sortOrder,
        page,
        limit,
      });
      setEmployees(res.data);
      setPagination(res.pagination);
    } catch {
      error('Failed to load employee list');
    } finally {
      setIsLoading(false);
    }
  }, [searchTerm, selectedDept, selectedStatus, sortBy, sortOrder, page, limit, error]);

  useEffect(() => {
    fetchEmployees();
  }, [fetchEmployees]);

  const handleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const handleOpenCreate = () => {
    setEditingEmployee(null);
    setIsEmployeeModalOpen(true);
  };

  const handleOpenEdit = (emp: Employee) => {
    setEditingEmployee(emp);
    setIsEmployeeModalOpen(true);
  };

  const handleOpenDelete = (emp: Employee) => {
    setDeletingEmployee(emp);
  };

  const handleSaveEmployee = async (formData: any) => {
    try {
      setIsSubmitting(true);
      if (editingEmployee) {
        await employeeApi.update(editingEmployee.id, formData);
        success(`Employee "${formData.full_name}" updated successfully.`);
      } else {
        await employeeApi.create(formData);
        success(`New employee "${formData.full_name}" onboarded successfully.`);
      }
      setIsEmployeeModalOpen(false);
      setEditingEmployee(null);
      fetchEmployees();
    } catch (err: any) {
      const msg = err.response?.data?.error || 'Failed to save employee record';
      error(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingEmployee) return;
    try {
      setIsSubmitting(true);
      await employeeApi.delete(deletingEmployee.id);
      success(`Employee "${deletingEmployee.full_name}" deleted.`);
      setDeletingEmployee(null);
      fetchEmployees();
    } catch (err: any) {
      const msg = err.response?.data?.error || 'Failed to delete employee';
      error(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExportCSV = async () => {
    try {
      // Fetch full set without pagination limit for complete export
      const full = await employeeApi.list({ limit: 1000 });
      exportToCSV(full.data, `employees_export_${new Date().toISOString().split('T')[0]}`);
      success(`Exported ${full.data.length} employee records to CSV.`);
    } catch {
      error('Failed to export employee dataset');
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Title & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Employee Management</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Directory, profile management, and role allocations across all departments.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold text-xs sm:text-sm transition-all"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleOpenCreate}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 transition-all"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Employee</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setPage(1);
              }}
              placeholder="Search by name, email, role, or ID..."
              className="w-full pl-9 pr-3.5 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-colors"
            />
          </div>

          {/* Department Filter */}
          <div>
            <select
              value={selectedDept}
              onChange={(e) => {
                setSelectedDept(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-colors bg-white text-slate-700"
            >
              <option value="">All Departments</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => {
                setSelectedStatus(e.target.value);
                setPage(1);
              }}
              className="w-full px-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 transition-colors bg-white text-slate-700"
            >
              <option value="all">All Statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="on_leave">On Leave</option>
            </select>
          </div>

          {/* Reset Filters / Refresh */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedDept('');
                setSelectedStatus('all');
                setSortBy('created_at');
                setSortOrder('desc');
                setPage(1);
              }}
              className="flex-1 py-2 px-3 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/80 rounded-xl transition-colors text-center"
            >
              Reset Filters
            </button>
            <button
              onClick={fetchEmployees}
              title="Refresh table"
              className="p-2 text-slate-600 hover:text-indigo-600 bg-slate-100 hover:bg-slate-200/80 rounded-xl transition-colors"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Employee Table */}
      <EmployeeTable
        employees={employees}
        pagination={pagination}
        isLoading={isLoading}
        sortBy={sortBy}
        sortOrder={sortOrder}
        onSort={handleSort}
        onPageChange={(newPage) => setPage(newPage)}
        onLimitChange={(newLimit) => {
          setLimit(newLimit);
          setPage(1);
        }}
        onEdit={handleOpenEdit}
        onDelete={handleOpenDelete}
      />

      {/* Add / Edit Employee Modal */}
      <EmployeeModal
        isOpen={isEmployeeModalOpen}
        onClose={() => {
          setIsEmployeeModalOpen(false);
          setEditingEmployee(null);
        }}
        onSubmit={handleSaveEmployee}
        employee={editingEmployee}
        departments={departments}
        isLoading={isSubmitting}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={!!deletingEmployee}
        title="Delete Employee Record"
        itemName={deletingEmployee?.full_name || ''}
        itemDescription={`Employee ID: ${deletingEmployee?.employee_id} • ${deletingEmployee?.designation}`}
        isLoading={isSubmitting}
        onConfirm={handleConfirmDelete}
        onClose={() => setDeletingEmployee(null)}
      />
    </div>
  );
};
