import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Users,
  UserCheck,
  UserX,
  Building2,
  DollarSign,
  TrendingUp,
  UserPlus,
  ArrowRight,
  ShieldCheck,
  Calendar,
  Layers
} from 'lucide-react';
import { StatCard } from '../components/StatCard.tsx';
import { DepartmentDistributionChart, JoiningTrendsChart } from '../components/Charts.tsx';
import { DashboardStats } from '../types/index.ts';
import { dashboardApi } from '../services/clientServices.ts';
import { formatCurrency, formatDate } from '../utils/formatters.ts';

export const DashboardPage: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchStats = async () => {
    try {
      setIsLoading(true);
      const data = await dashboardApi.getStats();
      setStats(data);
    } catch (err) {
      console.error('Failed to load dashboard stats', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Executive Dashboard</h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time organizational telemetry, workforce distribution, and payroll insights.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <Link
            to="/employees?action=new"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs sm:text-sm shadow-md shadow-indigo-600/30 transition-all"
          >
            <UserPlus className="w-4 h-4" />
            <span>Onboard Employee</span>
          </Link>
          <Link
            to="/departments"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold text-xs sm:text-sm transition-all"
          >
            <Building2 className="w-4 h-4 text-slate-500" />
            <span>Departments</span>
          </Link>
        </div>
      </div>

      {/* KPI Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Workforce"
          value={isLoading ? '...' : stats?.totalEmployees ?? 0}
          subtitle="Registered staff members"
          icon={Users}
          colorScheme="indigo"
          trend={{ value: '+12% YoY', isPositive: true }}
        />
        <StatCard
          title="Active Employees"
          value={isLoading ? '...' : stats?.activeEmployees ?? 0}
          subtitle={`${stats ? Math.round((stats.activeEmployees / Math.max(stats.totalEmployees, 1)) * 100) : 0}% utilization`}
          icon={UserCheck}
          colorScheme="emerald"
        />
        <StatCard
          title="Inactive / On Leave"
          value={isLoading ? '...' : (stats?.inactiveEmployees ?? 0) + (stats?.onLeaveEmployees ?? 0)}
          subtitle={`${stats?.onLeaveEmployees ?? 0} currently on leave`}
          icon={UserX}
          colorScheme="amber"
        />
        <StatCard
          title="Departments"
          value={isLoading ? '...' : stats?.totalDepartments ?? 0}
          subtitle="Operating business units"
          icon={Building2}
          colorScheme="sky"
        />
      </div>

      {/* Secondary Financial KPI bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Annual Active Payroll
            </span>
            <div className="text-2xl font-bold tracking-tight text-slate-900 mt-1">
              {isLoading ? '...' : formatCurrency(stats?.totalPayroll ?? 0)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Sum of all active contract salaries</p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
              Average Base Salary
            </span>
            <div className="text-2xl font-bold tracking-tight text-slate-900 mt-1">
              {isLoading ? '...' : formatCurrency(stats?.averageSalary ?? 0)}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">Mean annual compensation per head</p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Analytics Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Distribution */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">Department Workforce Allocation</h2>
              <p className="text-xs text-slate-500">Headcount distribution and department budgets</p>
            </div>
            <Link
              to="/departments"
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
            >
              <span>Manage</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <DepartmentDistributionChart data={stats?.departmentDistribution || []} />
        </div>

        {/* Joining Trends */}
        <div className="p-6 bg-white rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-base font-bold text-slate-900">Talent Acquisition Trends</h2>
              <p className="text-xs text-slate-500">Quarterly employee onboarding velocity</p>
            </div>
            <span className="text-xs font-semibold text-slate-500">Historical Timeline</span>
          </div>
          <JoiningTrendsChart data={stats?.joiningTrends || []} />
        </div>
      </div>

      {/* Recent Onboarded Employees */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">Recently Onboarded Team Members</h2>
            <p className="text-xs text-slate-500">Latest additions to the workforce roster</p>
          </div>
          <Link
            to="/employees"
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
          >
            <span>View All Directory</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="divide-y divide-slate-100">
          {isLoading ? (
            <div className="py-8 text-center text-sm text-slate-500">Loading recent employees...</div>
          ) : (stats?.recentEmployees?.length ?? 0) === 0 ? (
            <div className="py-8 text-center text-sm text-slate-500">No employees recorded</div>
          ) : (
            stats?.recentEmployees.map((emp) => (
              <div key={emp.id} className="p-4 sm:px-6 hover:bg-slate-50/70 transition-colors flex items-center justify-between gap-4">
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center font-bold text-sm shrink-0">
                    {emp.full_name.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Link
                        to={`/employees/${emp.id}`}
                        className="font-semibold text-slate-900 text-sm hover:text-indigo-600 transition-colors truncate"
                      >
                        {emp.full_name}
                      </Link>
                      <span className="text-[10px] font-mono text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded shrink-0">
                        {emp.employee_id}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500 truncate">
                      {emp.designation} • <span className="font-medium text-slate-700">{emp.department_name}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-right shrink-0">
                  <div className="hidden sm:block">
                    <div className="text-xs font-mono font-semibold text-slate-900">
                      {formatCurrency(emp.salary)}
                    </div>
                    <div className="text-[11px] text-slate-400">Joined {formatDate(emp.joining_date)}</div>
                  </div>
                  <Link
                    to={`/employees/${emp.id}`}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 transition-colors"
                  >
                    Profile
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
