import { db } from '../config/db.ts';
import { AuthService } from '../services/authService.ts';
import { EmployeeService } from '../services/employeeService.ts';
import { DepartmentService } from '../services/departmentService.ts';
import { DashboardService } from '../services/dashboardService.ts';

interface TestResult {
  suite: string;
  name: string;
  passed: boolean;
  error?: string;
  durationMs: number;
}

export async function runAllTests(): Promise<{ results: TestResult[]; summary: { total: number; passed: number; failed: number } }> {
  const results: TestResult[] = [];
  
  // Helper
  async function test(suite: string, name: string, fn: () => Promise<void> | void) {
    const start = performance.now();
    try {
      await fn();
      results.push({ suite, name, passed: true, durationMs: Math.round(performance.now() - start) });
    } catch (err: any) {
      results.push({
        suite,
        name,
        passed: false,
        error: err.message || JSON.stringify(err),
        durationMs: Math.round(performance.now() - start),
      });
    }
  }

  function assert(condition: boolean, msg: string) {
    if (!condition) throw new Error(msg);
  }

  // ==========================================
  // 1. MySQL Connectivity & Engine Verification
  // ==========================================
  await test('MySQL Engine', 'Verify live MySQL connection pool and version', async () => {
    const status = await db.testConnection();
    assert(status.connected === true, `MySQL connection failed: ${status.error}`);
    assert(!!status.database, 'Database name must be present');
    assert(!!status.version, 'MySQL version must be reported');
  });

  // Ensure clean DB state before test execution
  await db.resetDatabase();

  // ==========================================
  // 2. Authentication Tests
  // ==========================================
  await test('Auth', 'Login with valid admin credentials should return JWT and user info', async () => {
    const res = await AuthService.login('admin@staffflow.com', 'admin123');
    assert(!!res.token, 'Token should be returned');
    assert(res.user.email === 'admin@staffflow.com', 'User email should match');
    assert(res.user.role === 'admin', 'Role should be admin');
  });

  await test('Auth', 'Login with invalid password should fail with 401', async () => {
    try {
      await AuthService.login('admin@staffflow.com', 'wrongpassword');
      assert(false, 'Should have thrown an error');
    } catch (err: any) {
      assert(err.statusCode === 401, 'Status code should be 401');
    }
  });

  await test('Auth', 'Register new user and get profile from MySQL', async () => {
    const randomSuffix = Math.floor(Math.random() * 100000);
    const newUser = await AuthService.register({
      username: `testuser_${randomSuffix}`,
      email: `test_${randomSuffix}@staffflow.com`,
      password: 'testPassword123!',
      name: 'Test Reviewer',
      role: 'hr_manager',
    });
    assert(newUser.username === `testuser_${randomSuffix}`, 'Username should match');

    const profile = await AuthService.getProfile(newUser.id);
    assert(profile.id === newUser.id, 'Fetched profile ID should match');
  });

  // ==========================================
  // 3. Department Management Tests
  // ==========================================
  let createdDeptId: number;

  await test('Departments', 'Create a new department in MySQL', async () => {
    const dept = await DepartmentService.create({
      name: 'Quality Assurance & Automation',
      description: 'End to end testing, automation framework, and CI/CD gates.',
      manager_name: 'Marcus Bell',
      budget: 150000,
    });
    assert(dept.name === 'Quality Assurance & Automation', 'Department name should match');
    assert(Number(dept.budget) === 150000, 'Budget should match');
    createdDeptId = dept.id;
  });

  await test('Departments', 'Duplicate department name should throw 409 conflict', async () => {
    try {
      await DepartmentService.create({
        name: 'Quality Assurance & Automation',
      });
      assert(false, 'Should have thrown duplicate error');
    } catch (err: any) {
      assert(err.statusCode === 409, 'Status code should be 409');
    }
  });

  await test('Departments', 'Prevent deletion of department with assigned employees (Foreign Key Integrity)', async () => {
    try {
      // Department 1 (Engineering) has assigned employees
      await DepartmentService.delete(1);
      assert(false, 'Should have prevented deletion');
    } catch (err: any) {
      assert(err.statusCode === 409, 'Status code should be 409');
    }
  });

  await test('Departments', 'Delete empty department succeeds in MySQL', async () => {
    await DepartmentService.delete(createdDeptId);
    const found = await DepartmentService.getById(createdDeptId);
    assert(found === null, 'Department should be deleted');
  });

  // ==========================================
  // 4. Employee Management CRUD Tests
  // ==========================================
  let createdEmpId: number;

  await test('Employees', 'Create new employee with auto-generated ID in MySQL', async () => {
    const emp = await EmployeeService.create({
      full_name: 'Eleanor Sterling',
      email: 'eleanor.sterling@staffflow.com',
      phone: '+1 (555) 999-8888',
      gender: 'Female',
      date_of_birth: '1994-08-15',
      department_id: 1,
      designation: 'Staff Security Engineer',
      joining_date: '2024-02-01',
      salary: 130000,
      status: 'active',
      address: '990 Mission St, San Francisco, CA',
    });

    assert(!!emp.employee_id, 'Employee ID should be auto generated');
    assert(emp.department_name === 'Engineering', 'Department name should be resolved');
    createdEmpId = emp.id;
  });

  await test('Employees', 'Duplicate email should throw 409 conflict', async () => {
    try {
      await EmployeeService.create({
        full_name: 'Copycat User',
        email: 'eleanor.sterling@staffflow.com',
        phone: '+1 (555) 111-2222',
        gender: 'Male',
        date_of_birth: '1990-01-01',
        department_id: 1,
        designation: 'Engineer',
        joining_date: '2024-01-01',
        salary: 80000,
        status: 'active',
        address: '',
      });
      assert(false, 'Should have thrown conflict');
    } catch (err: any) {
      assert(err.statusCode === 409, 'Should be 409');
    }
  });

  await test('Employees', 'Search and filter employees by department and status in MySQL', async () => {
    const list = await EmployeeService.list({
      search: 'Eleanor',
      department_id: 1,
      status: 'active',
      page: 1,
      limit: 10,
    });
    assert(list.data.length >= 1, 'Should find at least 1 employee');
    assert(list.data[0].email === 'eleanor.sterling@staffflow.com', 'Should match search');
  });

  await test('Employees', 'Update employee details in MySQL', async () => {
    const updated = await EmployeeService.update(createdEmpId, {
      designation: 'Lead Security Architect',
      salary: 145000,
    });
    assert(updated.designation === 'Lead Security Architect', 'Designation should update');
    assert(Number(updated.salary) === 145000, 'Salary should update');
  });

  await test('Employees', 'Delete employee record from MySQL', async () => {
    await EmployeeService.delete(createdEmpId);
    const found = await EmployeeService.getById(createdEmpId);
    assert(found === null, 'Employee should be deleted');
  });

  // ==========================================
  // 5. MySQL Transactions Integration Test
  // ==========================================
  await test('MySQL Transactions', 'Transaction rollback preserves data integrity on error', async () => {
    const beforeCount = await db.get<{ total: number }>('SELECT COUNT(*) as total FROM departments');
    try {
      await db.transaction(async (conn) => {
        await conn.execute('INSERT INTO departments (name, budget) VALUES (?, ?)', ['Temp Dept', 1000]);
        // Trigger intentional error to verify rollback
        throw new Error('Simulated transaction abort');
      });
    } catch {
      // Expected rollback
    }
    const afterCount = await db.get<{ total: number }>('SELECT COUNT(*) as total FROM departments');
    assert(Number(beforeCount?.total) === Number(afterCount?.total), 'Transaction rollback failed');
  });

  // ==========================================
  // 6. Dashboard Statistics Tests
  // ==========================================
  await test('Dashboard', 'Calculate stats, department distribution, and joining trends via MySQL', async () => {
    const stats = await DashboardService.getStats();
    assert(stats.totalEmployees > 0, 'Total employees should be > 0');
    assert(stats.activeEmployees > 0, 'Active employees should be > 0');
    assert(stats.totalDepartments > 0, 'Total departments should be > 0');
    assert(stats.departmentDistribution.length > 0, 'Department distribution should have entries');
    assert(stats.joiningTrends.length > 0, 'Joining trends should have data');
  });

  const total = results.length;
  const passed = results.filter((r) => r.passed).length;
  const failed = total - passed;

  return { results, summary: { total, passed, failed } };
}

// If executed directly from CLI (e.g., tsx src/tests/runTests.ts)
if (process.argv[1] && process.argv[1].endsWith('runTests.ts')) {
  runAllTests().then(({ results, summary }) => {
    console.log('\n========================================');
    console.log('  StaffFlow MySQL Test Suite Results');
    console.log('========================================');
    for (const res of results) {
      const icon = res.passed ? '✓' : '✗';
      console.log(` ${icon} [${res.suite}] ${res.name} (${res.durationMs}ms)`);
      if (!res.passed && res.error) {
        console.error(`   Error: ${res.error}`);
      }
    }
    console.log('----------------------------------------');
    console.log(` Total: ${summary.total} | Passed: ${summary.passed} | Failed: ${summary.failed}`);
    console.log('========================================\n');
    process.exit(summary.failed > 0 ? 1 : 0);
  });
}
