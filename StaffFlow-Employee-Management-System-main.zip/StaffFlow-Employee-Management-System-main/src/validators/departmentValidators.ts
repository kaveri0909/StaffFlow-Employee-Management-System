import { z } from 'zod';

export const createDepartmentSchema = z.object({
  name: z.string().min(2, 'Department name must be at least 2 characters').max(100).trim(),
  description: z.string().max(500).optional().nullable(),
  manager_name: z.string().max(100).optional().nullable(),
  budget: z.coerce.number().min(0, 'Budget must be a non-negative number').default(0),
});

export const updateDepartmentSchema = createDepartmentSchema.partial();
