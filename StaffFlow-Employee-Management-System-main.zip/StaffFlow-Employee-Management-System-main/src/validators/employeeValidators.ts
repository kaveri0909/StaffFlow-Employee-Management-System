import { z } from 'zod';

export const createEmployeeSchema = z.object({
  employee_id: z.string().trim().optional(),
  full_name: z.string().min(2, 'Full name must be at least 2 characters').max(100).trim(),
  email: z.string().email('Please enter a valid email address').trim().toLowerCase(),
  phone: z.string().min(5, 'Valid phone number is required').max(30).trim(),
  gender: z.enum(['Male', 'Female', 'Other', 'Prefer not to say']),
  date_of_birth: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Date of birth must be YYYY-MM-DD'),
  department_id: z.coerce.number().int().positive('Please select a valid department'),
  designation: z.string().min(2, 'Designation is required').max(100).trim(),
  joining_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Joining date must be YYYY-MM-DD'),
  salary: z.coerce.number().min(0, 'Salary must be a non-negative number'),
  status: z.enum(['active', 'inactive', 'on_leave']).default('active'),
  address: z.string().max(500).optional().nullable(),
});

export const updateEmployeeSchema = createEmployeeSchema.partial();

export const employeeQuerySchema = z.object({
  search: z.string().optional(),
  department_id: z.coerce.number().int().positive().optional(),
  status: z.enum(['active', 'inactive', 'on_leave', 'all']).optional(),
  sortBy: z.enum(['full_name', 'joining_date', 'salary', 'created_at', 'employee_id']).optional().default('created_at'),
  sortOrder: z.enum(['asc', 'desc']).optional().default('desc'),
  page: z.coerce.number().int().positive().optional().default(1),
  limit: z.coerce.number().int().positive().max(100).optional().default(10),
});
