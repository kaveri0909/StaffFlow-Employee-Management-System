import { db } from '../config/db.ts';
import { Employee, PaginatedResult } from '../types/index.ts';

export interface EmployeeFilters {
  search?: string;
  department_id?: number;
  status?: string;
  sortBy?: 'full_name' | 'joining_date' | 'salary' | 'created_at' | 'employee_id';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export class EmployeeService {
  static async list(filters: EmployeeFilters): Promise<PaginatedResult<Employee>> {
    const page = Math.max(1, filters.page || 1);
    const limit = Math.max(1, Math.min(100, filters.limit || 10));
    const offset = (page - 1) * limit;

    const conditions: string[] = [];
    const params: any[] = [];

    if (filters.search && filters.search.trim()) {
      const term = `%${filters.search.trim()}%`;
      conditions.push('(e.full_name LIKE ? OR e.email LIKE ? OR e.employee_id LIKE ? OR e.designation LIKE ?)');
      params.push(term, term, term, term);
    }

    if (filters.department_id) {
      conditions.push('e.department_id = ?');
      params.push(filters.department_id);
    }

    if (filters.status && filters.status !== 'all') {
      conditions.push('e.status = ?');
      params.push(filters.status);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    // Count query
    const countSql = `SELECT COUNT(*) as total FROM employees e ${whereClause}`;
    const totalResult = await db.get<{ total: number }>(countSql, params);
    const total = totalResult ? Number(totalResult.total) : 0;

    // Sorting
    const allowedSortFields = ['full_name', 'joining_date', 'salary', 'created_at', 'employee_id'];
    const sortBy = allowedSortFields.includes(filters.sortBy || '') ? filters.sortBy! : 'created_at';
    const sortOrder = filters.sortOrder === 'asc' ? 'ASC' : 'DESC';

    // Data query (MySQL LIMIT and OFFSET as numbers in SQL string to avoid driver prepared statement limit typing quirks)
    const dataSql = `
      SELECT 
        e.id,
        e.employee_id,
        e.full_name,
        e.email,
        e.phone,
        e.gender,
        e.date_of_birth,
        e.department_id,
        d.name as department_name,
        e.designation,
        e.joining_date,
        e.salary,
        e.status,
        e.address,
        e.created_at,
        e.updated_at
      FROM employees e
      LEFT JOIN departments d ON e.department_id = d.id
      ${whereClause}
      ORDER BY e.${sortBy} ${sortOrder}
      LIMIT ${Number(limit)} OFFSET ${Number(offset)}
    `;

    const data = await db.query<Employee>(dataSql, params);

    const totalPages = Math.ceil(total / limit) || 1;

    return {
      data,
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
    };
  }

  static async getById(id: number): Promise<Employee | null> {
    const sql = `
      SELECT 
        e.id,
        e.employee_id,
        e.full_name,
        e.email,
        e.phone,
        e.gender,
        e.date_of_birth,
        e.department_id,
        d.name as department_name,
        e.designation,
        e.joining_date,
        e.salary,
        e.status,
        e.address,
        e.created_at,
        e.updated_at
      FROM employees e
      LEFT JOIN departments d ON e.department_id = d.id
      WHERE e.id = ?
    `;
    const employee = await db.get<Employee>(sql, [id]);
    return employee || null;
  }

  static async generateNextEmployeeId(): Promise<string> {
    const last = await db.get<{ employee_id: string }>(
      "SELECT employee_id FROM employees WHERE employee_id LIKE 'EMP-%' ORDER BY id DESC LIMIT 1"
    );
    if (!last || !last.employee_id) return 'EMP-1001';
    const match = last.employee_id.match(/EMP-(\d+)/);
    if (match) {
      const num = parseInt(match[1], 10) + 1;
      return `EMP-${num}`;
    }
    return `EMP-${Date.now().toString().slice(-4)}`;
  }

  static async create(data: Omit<Employee, 'id' | 'created_at' | 'updated_at' | 'department_name' | 'employee_id'> & { employee_id?: string }): Promise<Employee> {
    // 1. Verify Department exists
    const dept = await db.get<{ id: number }>('SELECT id FROM departments WHERE id = ?', [data.department_id]);
    if (!dept) {
      throw { statusCode: 400, message: `Department with ID ${data.department_id} does not exist.` };
    }

    // 2. Verify Email is unique
    const existingEmail = await db.get<{ id: number }>('SELECT id FROM employees WHERE LOWER(email) = LOWER(?)', [data.email]);
    if (existingEmail) {
      throw { statusCode: 409, message: `An employee with email '${data.email}' already exists.` };
    }

    // 3. Employee ID
    const employeeId = data.employee_id && data.employee_id.trim()
      ? data.employee_id.trim()
      : await this.generateNextEmployeeId();

    const existingEmpId = await db.get<{ id: number }>('SELECT id FROM employees WHERE employee_id = ?', [employeeId]);
    if (existingEmpId) {
      throw { statusCode: 409, message: `Employee ID '${employeeId}' is already in use.` };
    }

    const result = await db.execute(
      `INSERT INTO employees (
        employee_id, full_name, email, phone, gender, date_of_birth,
        department_id, designation, joining_date, salary, status, address
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        employeeId,
        data.full_name.trim(),
        data.email.trim().toLowerCase(),
        data.phone.trim(),
        data.gender,
        data.date_of_birth,
        data.department_id,
        data.designation.trim(),
        data.joining_date,
        data.salary,
        data.status || 'active',
        data.address || null,
      ]
    );

    const created = await this.getById(result.insertId);
    return created!;
  }

  static async update(id: number, data: Partial<Omit<Employee, 'id' | 'created_at' | 'updated_at' | 'department_name'>>): Promise<Employee> {
    const existing = await this.getById(id);
    if (!existing) {
      throw { statusCode: 404, message: 'Employee not found' };
    }

    // Check email unique if changed
    if (data.email && data.email.toLowerCase() !== existing.email.toLowerCase()) {
      const emailDup = await db.get<{ id: number }>('SELECT id FROM employees WHERE LOWER(email) = LOWER(?) AND id != ?', [data.email, id]);
      if (emailDup) {
        throw { statusCode: 409, message: `Another employee with email '${data.email}' already exists.` };
      }
    }

    // Check department if changed
    if (data.department_id && data.department_id !== existing.department_id) {
      const dept = await db.get<{ id: number }>('SELECT id FROM departments WHERE id = ?', [data.department_id]);
      if (!dept) {
        throw { statusCode: 400, message: `Department with ID ${data.department_id} does not exist.` };
      }
    }

    // Check employee_id if changed
    if (data.employee_id && data.employee_id !== existing.employee_id) {
      const empIdDup = await db.get<{ id: number }>('SELECT id FROM employees WHERE employee_id = ? AND id != ?', [data.employee_id, id]);
      if (empIdDup) {
        throw { statusCode: 409, message: `Employee ID '${data.employee_id}' is already assigned to another employee.` };
      }
    }

    const updated = {
      employee_id: data.employee_id !== undefined ? data.employee_id.trim() : existing.employee_id,
      full_name: data.full_name !== undefined ? data.full_name.trim() : existing.full_name,
      email: data.email !== undefined ? data.email.trim().toLowerCase() : existing.email,
      phone: data.phone !== undefined ? data.phone.trim() : existing.phone,
      gender: data.gender !== undefined ? data.gender : existing.gender,
      date_of_birth: data.date_of_birth !== undefined ? data.date_of_birth : existing.date_of_birth,
      department_id: data.department_id !== undefined ? data.department_id : existing.department_id,
      designation: data.designation !== undefined ? data.designation.trim() : existing.designation,
      joining_date: data.joining_date !== undefined ? data.joining_date : existing.joining_date,
      salary: data.salary !== undefined ? data.salary : existing.salary,
      status: data.status !== undefined ? data.status : existing.status,
      address: data.address !== undefined ? data.address : existing.address,
    };

    await db.execute(
      `UPDATE employees SET
        employee_id = ?,
        full_name = ?,
        email = ?,
        phone = ?,
        gender = ?,
        date_of_birth = ?,
        department_id = ?,
        designation = ?,
        joining_date = ?,
        salary = ?,
        status = ?,
        address = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?`,
      [
        updated.employee_id,
        updated.full_name,
        updated.email,
        updated.phone,
        updated.gender,
        updated.date_of_birth,
        updated.department_id,
        updated.designation,
        updated.joining_date,
        updated.salary,
        updated.status,
        updated.address,
        id,
      ]
    );

    const result = await this.getById(id);
    return result!;
  }

  static async delete(id: number): Promise<void> {
    const existing = await db.get<{ id: number }>('SELECT id FROM employees WHERE id = ?', [id]);
    if (!existing) {
      throw { statusCode: 404, message: 'Employee not found' };
    }
    await db.execute('DELETE FROM employees WHERE id = ?', [id]);
  }
}
