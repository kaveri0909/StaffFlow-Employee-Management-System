import { db } from '../config/db.ts';
import { comparePassword, hashPassword } from '../utils/password.ts';
import { signToken } from '../utils/jwt.ts';
import { User, JwtPayload } from '../types/index.ts';

export class AuthService {
  static async login(emailOrUsername: string, pass: string): Promise<{ token: string; user: Omit<User, 'password_hash'> }> {
    const user = await db.get<User>(
      'SELECT id, username, email, password_hash, name, role, created_at FROM users WHERE email = ? OR username = ?',
      [emailOrUsername.toLowerCase(), emailOrUsername]
    );

    if (!user || !user.password_hash) {
      throw { statusCode: 401, message: 'Invalid credentials. User not found.' };
    }

    const isValid = await comparePassword(pass, user.password_hash);
    if (!isValid) {
      throw { statusCode: 401, message: 'Invalid credentials. Incorrect password.' };
    }

    const payload: JwtPayload = {
      userId: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
      name: user.name,
    };

    const token = signToken(payload);
    const { password_hash, ...safeUser } = user;

    return { token, user: safeUser };
  }

  static async register(data: {
    username: string;
    email: string;
    password: string;
    name: string;
    role?: 'admin' | 'hr_manager' | 'viewer';
  }): Promise<Omit<User, 'password_hash'>> {
    // Check existing
    const existing = await db.get<User>(
      'SELECT id FROM users WHERE email = ? OR username = ?',
      [data.email.toLowerCase(), data.username]
    );

    if (existing) {
      throw { statusCode: 409, message: 'A user with this email or username already exists' };
    }

    const passwordHash = await hashPassword(data.password);
    const role = data.role || 'admin';

    const result = await db.execute(
      'INSERT INTO users (username, email, password_hash, name, role) VALUES (?, ?, ?, ?, ?)',
      [data.username, data.email.toLowerCase(), passwordHash, data.name, role]
    );

    const newUser = await db.get<User>(
      'SELECT id, username, email, name, role, created_at FROM users WHERE id = ?',
      [result.insertId]
    );

    if (!newUser) {
      throw { statusCode: 500, message: 'Failed to create user account' };
    }

    return newUser;
  }

  static async getProfile(userId: number): Promise<Omit<User, 'password_hash'>> {
    const user = await db.get<User>(
      'SELECT id, username, email, name, role, created_at, updated_at FROM users WHERE id = ?',
      [userId]
    );

    if (!user) {
      throw { statusCode: 404, message: 'User profile not found' };
    }

    return user;
  }
}
