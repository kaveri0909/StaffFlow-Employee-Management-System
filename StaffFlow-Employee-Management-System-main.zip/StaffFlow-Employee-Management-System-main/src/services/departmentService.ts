import { db } from '../config/db.ts';
import { Department, Employee } from '../types/index.ts';

export class DepartmentService {
  static async getAll(): Promise<Department[]> {
    const sql = `
      SELECT 
        d.id, 
        d.name, 
        d.description, 
        d.manager_name, 
        d.budget,
        d.created_at, 
        d.updated_at,
        COUNT(e.id) as employee_count
      FROM departments d
      LEFT JOIN employees e ON d.id = e.department_id
      GROUP BY d.id
      ORDER BY d.name ASC
    `;
    return await db.query<Department>(sql);
  }

  static async getById(id: number): Promise<(Department & { employees: Employee[] }) | null> {
    const dept = await db.get<Department>(
      'SELECT id, name, description, manager_name, budget, created_at, updated_at FROM departments WHERE id = ?',
      [id]
    );

    if (!dept) return null;

    const employees = await db.query<Employee>(
      `SELECT id, employee_id, full_name, email, phone, gender, designation, joining_date, salary, status 
       FROM employees 
       WHERE department_id = ? 
       ORDER BY full_name ASC`,
      [id]
    );

    return {
      ...dept,
      employee_count: employees.length,
      employees,
    };
  }

  static async create(data: { name: string; description?: string | null; manager_name?: string | null; budget?: number }): Promise<Department> {
    // Check unique name
    const existing = await db.get<Department>('SELECT id FROM departments WHERE LOWER(name) = LOWER(?)', [data.name]);
    if (existing) {
      throw { statusCode: 409, message: `Department '${data.name}' already exists.` };
    }

    const result = await db.execute(
      'INSERT INTO departments (name, description, manager_name, budget) VALUES (?, ?, ?, ?)',
      [data.name.trim(), data.description || null, data.manager_name || null, data.budget || 0]
    );

    const created = await db.get<Department>('SELECT * FROM departments WHERE id = ?', [result.insertId]);
    return { ...created!, employee_count: 0 };
  }

  static async update(id: number, data: Partial<{ name: string; description: string | null; manager_name: string | null; budget: number }>): Promise<Department> {
    const existing = await db.get<Department>('SELECT * FROM departments WHERE id = ?', [id]);
    if (!existing) {
      throw { statusCode: 404, message: 'Department not found' };
    }

    if (data.name && data.name.toLowerCase() !== existing.name.toLowerCase()) {
      const duplicate = await db.get<Department>('SELECT id FROM departments WHERE LOWER(name) = LOWER(?) AND id != ?', [data.name, id]);
      if (duplicate) {
        throw { statusCode: 409, message: `Another department named '${data.name}' already exists.` };
      }
    }

    const name = data.name !== undefined ? data.name.trim() : existing.name;
    const description = data.description !== undefined ? data.description : existing.description;
    const manager_name = data.manager_name !== undefined ? data.manager_name : existing.manager_name;
    const budget = data.budget !== undefined ? data.budget : existing.budget;

    await db.execute(
      `UPDATE departments 
       SET name = ?, description = ?, manager_name = ?, budget = ?, updated_at = CURRENT_TIMESTAMP 
       WHERE id = ?`,
      [name, description, manager_name, budget, id]
    );

    const updated = await db.get<Department>('SELECT * FROM departments WHERE id = ?', [id]);
    return updated!;
  }

  static async delete(id: number): Promise<void> {
    const dept = await db.get<Department>('SELECT id, name FROM departments WHERE id = ?', [id]);
    if (!dept) {
      throw { statusCode: 404, message: 'Department not found' };
    }

    const empCount = await db.get<{ count: number }>('SELECT COUNT(*) as count FROM employees WHERE department_id = ?', [id]);
    if (empCount && empCount.count > 0) {
      throw {
        statusCode: 409,
        message: `Cannot delete department '${dept.name}' because it contains ${empCount.count} assigned employee(s). Reassign or remove employees first.`
      };
    }

    await db.execute('DELETE FROM departments WHERE id = ?', [id]);
  }
}
