import { api } from './api.ts';
import {
  ApiResponse,
  User,
  Employee,
  Department,
  PaginatedResult,
  DashboardStats,
} from '../types/index.ts';

export const authApi = {
  login: async (emailOrUsername: string, pass: string) => {
    const res = await api.post<ApiResponse<{ token: string; user: User }>>('/auth/login', {
      emailOrUsername,
      password: pass,
    });
    return res.data.data!;
  },
  logout: async () => {
    const res = await api.post<ApiResponse<{ loggedOut: boolean }>>('/auth/logout');
    return res.data.data;
  },
  getProfile: async () => {
    const res = await api.get<ApiResponse<User>>('/auth/profile');
    return res.data.data!;
  },
};

export interface EmployeeQueryParams {
  search?: string;
  department_id?: number | string;
  status?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export const employeeApi = {
  list: async (params: EmployeeQueryParams = {}) => {
    const res = await api.get<ApiResponse<PaginatedResult<Employee>>>('/employees', { params });
    return res.data.data!;
  },
  getById: async (id: number | string) => {
    const res = await api.get<ApiResponse<Employee>>(`/employees/${id}`);
    return res.data.data!;
  },
  create: async (payload: Partial<Employee>) => {
    const res = await api.post<ApiResponse<Employee>>('/employees', payload);
    return res.data.data!;
  },
  update: async (id: number | string, payload: Partial<Employee>) => {
    const res = await api.put<ApiResponse<Employee>>(`/employees/${id}`, payload);
    return res.data.data!;
  },
  delete: async (id: number | string) => {
    const res = await api.delete<ApiResponse<{ id: number }>>(`/employees/${id}`);
    return res.data.data!;
  },
};

export const departmentApi = {
  list: async () => {
    const res = await api.get<ApiResponse<Department[]>>('/departments');
    return res.data.data!;
  },
  getById: async (id: number | string) => {
    const res = await api.get<ApiResponse<Department & { employees: Employee[] }>>(`/departments/${id}`);
    return res.data.data!;
  },
  create: async (payload: Partial<Department>) => {
    const res = await api.post<ApiResponse<Department>>('/departments', payload);
    return res.data.data!;
  },
  update: async (id: number | string, payload: Partial<Department>) => {
    const res = await api.put<ApiResponse<Department>>(`/departments/${id}`, payload);
    return res.data.data!;
  },
  delete: async (id: number | string) => {
    const res = await api.delete<ApiResponse<{ id: number }>>(`/departments/${id}`);
    return res.data.data!;
  },
};

export const dashboardApi = {
  getStats: async () => {
    const res = await api.get<ApiResponse<DashboardStats>>('/dashboard/stats');
    return res.data.data!;
  },
  resetData: async () => {
    const res = await api.post<ApiResponse<DashboardStats>>('/dashboard/reset');
    return res.data.data!;
  },
};

export const testApi = {
  runTests: async () => {
    const res = await api.get<ApiResponse<any>>('/tests/run');
    return res.data.data!;
  },
};
