import { db } from '../config/db.ts';
import { DashboardStats, Employee } from '../types/index.ts';

export class DashboardService {
  static async getStats(): Promise<DashboardStats> {
    // 1. Employee status counts
    const statusCounts = await db.query<{ status: string; count: number }>(`
      SELECT status, COUNT(*) as count 
      FROM employees 
      GROUP BY status
    `);

    let totalEmployees = 0;
    let activeEmployees = 0;
    let inactiveEmployees = 0;
    let onLeaveEmployees = 0;

    for (const row of statusCounts) {
      const count = Number(row.count);
      totalEmployees += count;
      if (row.status === 'active') activeEmployees = count;
      else if (row.status === 'inactive') inactiveEmployees = count;
      else if (row.status === 'on_leave') onLeaveEmployees = count;
    }

    // 2. Department count
    const deptCount = await db.get<{ count: number }>('SELECT COUNT(*) as count FROM departments');
    const totalDepartments = deptCount ? Number(deptCount.count) : 0;

    // 3. Salary analytics
    const salaryStats = await db.get<{ totalPayroll: number; averageSalary: number }>(`
      SELECT 
        COALESCE(SUM(salary), 0) as totalPayroll,
        COALESCE(AVG(salary), 0) as averageSalary
      FROM employees
      WHERE status = 'active'
    `);

    // 4. Recent employees (latest 5)
    const recentEmployees = await db.query<Employee>(`
      SELECT 
        e.id,
        e.employee_id,
        e.full_name,
        e.email,
        e.phone,
        e.gender,
        e.date_of_birth,
        e.department_id,
        d.name as department_name,
        e.designation,
        e.joining_date,
        e.salary,
        e.status,
        e.created_at
      FROM employees e
      LEFT JOIN departments d ON e.department_id = d.id
      ORDER BY e.id DESC
      LIMIT 5
    `);

    // 5. Department-wise employee distribution
    const deptDistributionRows = await db.query<{
      departmentId: number;
      departmentName: string;
      employeeCount: number;
      totalSalary: number;
    }>(`
      SELECT 
        d.id as departmentId,
        d.name as departmentName,
        COUNT(e.id) as employeeCount,
        COALESCE(SUM(e.salary), 0) as totalSalary
      FROM departments d
      LEFT JOIN employees e ON d.id = e.department_id
      GROUP BY d.id
      ORDER BY employeeCount DESC
    `);

    const departmentDistribution = deptDistributionRows.map((row) => ({
      ...row,
      employeeCount: Number(row.employeeCount),
      totalSalary: Number(row.totalSalary),
      percentage: totalEmployees > 0 ? Math.round((Number(row.employeeCount) / totalEmployees) * 100) : 0,
    }));

    // 6. Employee joining trends (MySQL CONCAT and QUARTER)
    const joiningTrendsRaw = await db.query<{ period: string; count: number }>(`
      SELECT 
        CONCAT(YEAR(joining_date), '-Q', QUARTER(joining_date)) as period,
        COUNT(*) as count
      FROM employees
      WHERE joining_date IS NOT NULL AND joining_date != '0000-00-00'
      GROUP BY period
      ORDER BY period ASC
      LIMIT 8
    `);

    const joiningTrends = joiningTrendsRaw.map((row) => ({
      period: row.period,
      count: Number(row.count),
    }));

    return {
      totalEmployees,
      activeEmployees,
      inactiveEmployees,
      onLeaveEmployees,
      totalDepartments,
      totalPayroll: salaryStats ? Math.round(Number(salaryStats.totalPayroll)) : 0,
      averageSalary: salaryStats ? Math.round(Number(salaryStats.averageSalary)) : 0,
      recentEmployees,
      departmentDistribution,
      joiningTrends,
    };
  }
}
