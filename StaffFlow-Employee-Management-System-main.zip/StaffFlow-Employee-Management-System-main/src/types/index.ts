export type UserRole = 'admin' | 'hr_manager' | 'viewer';

export interface User {
  id: number;
  username: string;
  email: string;
  password_hash?: string;
  name: string;
  role: UserRole;
  created_at?: string;
  updated_at?: string;
}

export interface Department {
  id: number;
  name: string;
  description: string | null;
  manager_name: string | null;
  budget: number;
  employee_count?: number;
  created_at?: string;
  updated_at?: string;
}

export type EmploymentStatus = 'active' | 'inactive' | 'on_leave';

export interface Employee {
  id: number;
  employee_id: string;
  full_name: string;
  email: string;
  phone: string;
  gender: 'Male' | 'Female' | 'Other' | 'Prefer not to say';
  date_of_birth: string;
  department_id: number;
  department_name?: string;
  designation: string;
  joining_date: string;
  salary: number;
  status: EmploymentStatus;
  address: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

export interface PaginatedResult<T> {
  data: T[];
  pagination: PaginationMeta;
}

export interface DashboardStats {
  totalEmployees: number;
  activeEmployees: number;
  inactiveEmployees: number;
  onLeaveEmployees: number;
  totalDepartments: number;
  totalPayroll: number;
  averageSalary: number;
  recentEmployees: Employee[];
  departmentDistribution: {
    departmentId: number;
    departmentName: string;
    employeeCount: number;
    totalSalary: number;
    percentage: number;
  }[];
  joiningTrends: {
    period: string; // e.g. "2023-Q1" or "Jan 2024"
    count: number;
  }[];
}

export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
  errors?: Record<string, string[]>;
}

export interface JwtPayload {
  userId: number;
  email: string;
  username: string;
  role: UserRole;
  name: string;
}
