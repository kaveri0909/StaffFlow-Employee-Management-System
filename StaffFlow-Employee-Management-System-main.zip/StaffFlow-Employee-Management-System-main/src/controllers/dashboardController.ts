import { Request, Response, NextFunction } from 'express';
import { DashboardService } from '../services/dashboardService.ts';
import { sendSuccess } from '../utils/apiResponse.ts';
import { db } from '../config/db.ts';

export class DashboardController {
  static async getStats(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const stats = await DashboardService.getStats();
      sendSuccess(res, stats, 'Dashboard statistics retrieved successfully', 200);
    } catch (error) {
      next(error);
    }
  }

  static async resetData(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      await db.resetDatabase();
      const stats = await DashboardService.getStats();
      sendSuccess(res, stats, 'Database has been reset with original seed data', 200);
    } catch (error) {
      next(error);
    }
  }
}
