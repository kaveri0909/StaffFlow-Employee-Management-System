import { Request, Response, NextFunction } from 'express';
import { DepartmentService } from '../services/departmentService.ts';
import { sendSuccess, sendError } from '../utils/apiResponse.ts';

export class DepartmentController {
  static async getAll(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const departments = await DepartmentService.getAll();
      sendSuccess(res, departments, 'Departments retrieved successfully', 200);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        sendError(res, 'Invalid department ID', 400);
        return;
      }

      const department = await DepartmentService.getById(id);
      if (!department) {
        sendError(res, 'Department not found', 404);
        return;
      }

      sendSuccess(res, department, 'Department details retrieved', 200);
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const created = await DepartmentService.create(req.body);
      sendSuccess(res, created, 'Department created successfully', 201);
    } catch (error) {
      next(error);
    }
  }

  static async update(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        sendError(res, 'Invalid department ID', 400);
        return;
      }

      const updated = await DepartmentService.update(id, req.body);
      sendSuccess(res, updated, 'Department updated successfully', 200);
    } catch (error) {
      next(error);
    }
  }

  static async delete(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        sendError(res, 'Invalid department ID', 400);
        return;
      }

      await DepartmentService.delete(id);
      sendSuccess(res, { id }, 'Department deleted successfully', 200);
    } catch (error) {
      next(error);
    }
  }
}
