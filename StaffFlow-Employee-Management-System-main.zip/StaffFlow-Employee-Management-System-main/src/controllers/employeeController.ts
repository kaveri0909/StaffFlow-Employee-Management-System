import { Request, Response, NextFunction } from 'express';
import { EmployeeService, EmployeeFilters } from '../services/employeeService.ts';
import { sendSuccess, sendError } from '../utils/apiResponse.ts';

export class EmployeeController {
  static async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const filters: EmployeeFilters = {
        search: req.query.search as string | undefined,
        department_id: req.query.department_id ? parseInt(req.query.department_id as string, 10) : undefined,
        status: req.query.status as string | undefined,
        sortBy: req.query.sortBy as any,
        sortOrder: req.query.sortOrder as any,
        page: req.query.page ? parseInt(req.query.page as string, 10) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string, 10) : 10,
      };

      const result = await EmployeeService.list(filters);
      sendSuccess(res, result, 'Employees retrieved successfully', 200);
    } catch (error) {
      next(error);
    }
  }

  static async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        sendError(res, 'Invalid employee ID', 400);
        return;
      }

      const employee = await EmployeeService.getById(id);
      if (!employee) {
        sendError(res, 'Employee not found', 404);
        return;
      }

      sendSuccess(res, employee, 'Employee profile details retrieved', 200);
    } catch (error) {
      next(error);
    }
  }

  static async create(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const employee = await EmployeeService.create(req.body);
      sendSuccess(res, employee, 'Employee created successfully', 201);
    } catch (error) {
      next(error);
    }
  }

  static async update(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        sendError(res, 'Invalid employee ID', 400);
        return;
      }

      const updated = await EmployeeService.update(id, req.body);
      sendSuccess(res, updated, 'Employee updated successfully', 200);
    } catch (error) {
      next(error);
    }
  }

  static async delete(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = parseInt(req.params.id, 10);
      if (isNaN(id)) {
        sendError(res, 'Invalid employee ID', 400);
        return;
      }

      await EmployeeService.delete(id);
      sendSuccess(res, { id }, 'Employee deleted successfully', 200);
    } catch (error) {
      next(error);
    }
  }
}
