import { Request, Response, NextFunction } from 'express';
import { AuthService } from '../services/authService.ts';
import { sendSuccess, sendError } from '../utils/apiResponse.ts';
import { AuthenticatedRequest } from '../middleware/authMiddleware.ts';

export class AuthController {
  static async login(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const { emailOrUsername, password } = req.body;
      const result = await AuthService.login(emailOrUsername, password);
      sendSuccess(res, result, 'Login successful', 200);
    } catch (error) {
      next(error);
    }
  }

  static async register(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const user = await AuthService.register(req.body);
      sendSuccess(res, user, 'User registered successfully', 201);
    } catch (error) {
      next(error);
    }
  }

  static async logout(_req: Request, res: Response): Promise<void> {
    // JWT is stateless; client drops the token, endpoint confirms session invalidation
    sendSuccess(res, { loggedOut: true }, 'Successfully logged out', 200);
  }

  static async getProfile(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user) {
        sendError(res, 'Unauthorized', 401);
        return;
      }
      const user = await AuthService.getProfile(req.user.userId);
      sendSuccess(res, user, 'Profile retrieved successfully', 200);
    } catch (error) {
      next(error);
    }
  }
}
