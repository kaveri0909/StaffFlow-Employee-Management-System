import mysql from 'mysql2/promise';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import type { Pool, PoolConnection, RowDataPacket, ResultSetHeader } from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import { config } from './env.ts';

// Detect whether connecting to a remote host (e.g. Aiven Cloud MySQL)
const isRemoteHost = config.mysql.host !== '127.0.0.1' && config.mysql.host !== 'localhost';
const isAivenPort = config.mysql.port !== 3306;
const requiresSSL = process.env.MYSQL_SSL === 'true' || isRemoteHost || isAivenPort;

// Centralized MySQL Connection Pool with Aiven SSL verification support
export const pool: Pool = mysql.createPool({
  host: config.mysql.host,
  port: config.mysql.port,
  user: config.mysql.user,
  password: config.mysql.password,
  database: config.mysql.database,
  waitForConnections: true,
  connectionLimit: config.mysql.connectionLimit,
  queueLimit: 0,
  dateStrings: true,
  decimalNumbers: true,
  enableKeepAlive: true,
  keepAliveInitialDelay: 10000,
  ssl: requiresSSL
    ? (() => {
        const caPath = resolve(process.cwd(), 'certs/ca.pem');
        if (!existsSync(caPath)) {
          throw new Error('Aiven CA certificate missing: certs/ca.pem');
        }
        return {
          ca: readFileSync(caPath),
          rejectUnauthorized: true,
        };
      })()
    : undefined,
});

// Centralized Asynchronous Database Interface
export const db = {
  // Query multiple rows
  async query<T = any>(sql: string, params: any[] = []): Promise<T[]> {
    const [rows] = await pool.query<RowDataPacket[]>(sql, params);
    return rows as unknown as T[];
  },

  // Query a single row
  async get<T = any>(sql: string, params: any[] = []): Promise<T | null> {
    const [rows] = await pool.query<RowDataPacket[]>(sql, params);
    if (!rows || rows.length === 0) return null;
    return rows[0] as unknown as T;
  },

  // Execute INSERT, UPDATE, DELETE
  async execute(sql: string, params: any[] = []): Promise<{ insertId: number; affectedRows: number }> {
    const [result] = await pool.execute<ResultSetHeader>(sql, params);
    return {
      insertId: result.insertId,
      affectedRows: result.affectedRows,
    };
  },

  // Managed Transaction Helper
  async transaction<T>(callback: (conn: PoolConnection) => Promise<T>): Promise<T> {
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      const result = await callback(conn);
      await conn.commit();
      return result;
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  },

  // Test Connection and Inspect Active Host Properties
  async testConnection(): Promise<{
    connected: boolean;
    version?: string;
    database?: string;
    hostname?: string;
    port?: number;
    targetHost?: string;
    targetPort?: number;
    error?: string;
  }> {
    try {
      const [rows] = await pool.query<RowDataPacket[]>(
        'SELECT DATABASE() as db, VERSION() as ver, @@hostname as server_host, @@port as server_port'
      );
      return {
        connected: true,
        version: rows[0]?.ver,
        database: rows[0]?.db,
        hostname: rows[0]?.server_host,
        port: rows[0]?.server_port,
        targetHost: config.mysql.host,
        targetPort: config.mysql.port,
      };
    } catch (err: any) {
      return {
        connected: false,
        targetHost: config.mysql.host,
        targetPort: config.mysql.port,
        error: err.message || String(err),
      };
    }
  },

  // Reset Database to Seed State
  async resetDatabase(): Promise<void> {
    throw new Error('Database reset is disabled to protect StaffFlow data.');
  },
};

// Auto-seed initial default dataset if tables are empty
export async function seedMySQL(): Promise<void> {
  if (!config.seedAdminPassword || !config.seedHrPassword) {
    throw new Error('SEED_ADMIN_PASSWORD and SEED_HR_PASSWORD must be configured.');
  }

  const adminPasswordHash = bcrypt.hashSync(config.seedAdminPassword, 12);
  const hrPasswordHash = bcrypt.hashSync(config.seedHrPassword, 12);

  // 1. Users
  await db.execute(
    `INSERT INTO users (id, username, email, password_hash, name, role) VALUES
     (1, 'admin', 'admin@staffflow.com', ?, 'System Administrator', 'admin'),
     (2, 'hrmanager', 'hr@staffflow.com', ?, 'Sarah Jenkins', 'hr_manager')
     ON DUPLICATE KEY UPDATE name=VALUES(name)`,
    [adminPasswordHash, hrPasswordHash]
  );

  // 2. Departments
  await db.execute(`
    INSERT INTO departments (id, name, description, manager_name, budget) VALUES
    (1, 'Engineering', 'Software development, infrastructure, and technical architecture.', 'Alex Chen', 650000.00),
    (2, 'Human Resources', 'Talent acquisition, employee welfare, compensation, and onboarding.', 'Sarah Jenkins', 180000.00),
    (3, 'Product Management', 'Product vision, feature roadmaps, analytics, and UX research.', 'Marcus Brody', 290000.00),
    (4, 'Marketing & Sales', 'Brand strategy, enterprise sales, content marketing, and growth.', 'Elena Rostova', 340000.00),
    (5, 'Finance & Legal', 'Accounting, audit, financial planning, compliance, and governance.', 'David Kim', 210000.00),
    (6, 'Customer Support', 'Client success, technical customer care, and satisfaction SLA.', 'Priya Sharma', 140000.00)
    ON DUPLICATE KEY UPDATE name=VALUES(name)
  `);

  // 3. Employees
  await db.execute(`
    INSERT INTO employees (id, employee_id, full_name, email, phone, gender, date_of_birth, department_id, designation, joining_date, salary, status, address) VALUES
    (1, 'EMP-1001', 'Alexander Hayes', 'alexander.hayes@staffflow.com', '+1 (555) 234-5678', 'Male', '1988-04-14', 1, 'Principal Software Engineer', '2022-03-15', 135000.00, 'active', '742 Evergreen Terrace, Springfield, OR'),
    (2, 'EMP-1002', 'Sophia Rodriguez', 'sophia.rodriguez@staffflow.com', '+1 (555) 345-6789', 'Female', '1992-09-21', 1, 'Senior Frontend Architect', '2022-06-01', 115000.00, 'active', '124 Conch Street, Pacific Grove, CA'),
    (3, 'EMP-1003', 'Liam O''Connor', 'liam.oconnor@staffflow.com', '+1 (555) 456-7890', 'Male', '1990-11-05', 1, 'DevOps & Cloud Engineer', '2023-01-10', 105000.00, 'active', '88 St. Marks Place, New York, NY'),
    (4, 'EMP-1004', 'Emily Watson', 'emily.watson@staffflow.com', '+1 (555) 567-8901', 'Female', '1994-02-18', 3, 'Lead Product Manager', '2022-08-20', 120000.00, 'active', '452 Pine Valley Rd, Austin, TX'),
    (5, 'EMP-1005', 'Marcus Vance', 'marcus.vance@staffflow.com', '+1 (555) 678-9012', 'Male', '1987-07-30', 2, 'Senior Talent Acquisition Lead', '2021-11-01', 88000.00, 'active', '303 Lincoln Way, Chicago, IL'),
    (6, 'EMP-1006', 'Aria Tanaka', 'aria.tanaka@staffflow.com', '+1 (555) 789-0123', 'Female', '1995-12-08', 4, 'Enterprise Account Executive', '2023-04-12', 95000.00, 'active', '910 Market Street, San Francisco, CA'),
    (7, 'EMP-1007', 'Nathanial Drake', 'nathanial.drake@staffflow.com', '+1 (555) 890-1234', 'Male', '1991-03-27', 4, 'Growth Marketing Director', '2022-02-15', 110000.00, 'active', '1802 Grand Ave, Seattle, WA'),
    (8, 'EMP-1008', 'Fatima Al-Mansoor', 'fatima.almansoor@staffflow.com', '+1 (555) 901-2345', 'Female', '1989-08-16', 5, 'Senior Financial Controller', '2021-09-01', 118000.00, 'active', '65 Commonwealth Ave, Boston, MA'),
    (9, 'EMP-1009', 'Jackson Reid', 'jackson.reid@staffflow.com', '+1 (555) 012-3456', 'Male', '1996-05-19', 1, 'Full Stack Engineer', '2023-09-01', 92000.00, 'active', '521 Boulder St, Denver, CO'),
    (10, 'EMP-1010', 'Chloe Bennett', 'chloe.bennett@staffflow.com', '+1 (555) 123-4560', 'Female', '1993-10-12', 6, 'Customer Success Manager', '2023-02-28', 78000.00, 'active', '44 Peachtree St, Atlanta, GA'),
    (11, 'EMP-1011', 'Devon Miller', 'devon.miller@staffflow.com', '+1 (555) 234-5671', 'Male', '1997-01-24', 6, 'Technical Support Specialist', '2024-01-15', 62000.00, 'inactive', '710 Broadway, Nashville, TN'),
    (12, 'EMP-1012', 'Hannah Zimmerman', 'hannah.zimmerman@staffflow.com', '+1 (555) 345-6782', 'Female', '1991-06-30', 3, 'Senior UX/UI Designer', '2023-07-10', 98000.00, 'on_leave', '110 Ocean Drive, Miami, FL')
    ON DUPLICATE KEY UPDATE full_name=VALUES(full_name)
  `);
}

// Graceful pool shutdown
process.on('SIGINT', async () => {
  await pool.end();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await pool.end();
  process.exit(0);
});
