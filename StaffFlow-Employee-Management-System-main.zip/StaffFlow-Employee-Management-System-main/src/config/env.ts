import dotenv from 'dotenv';
dotenv.config();

const isProduction = process.env.NODE_ENV === 'production';

function requiredEnv(name: string, fallback?: string): string {
  const value = process.env[name] || fallback;

  if (!value && isProduction) {
    throw new Error(`Missing required environment variable: ${name}`);
  }

  return value || '';
}

const jwtSecret = requiredEnv(
  'JWT_SECRET',
  isProduction ? undefined : 'development-only-secret-change-me'
);

if (isProduction && jwtSecret.length < 32) {
  throw new Error('JWT_SECRET must be at least 32 characters in production');
}

export const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  jwtSecret,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',

  seedAdminPassword: requiredEnv('SEED_ADMIN_PASSWORD'),
  seedHrPassword: requiredEnv('SEED_HR_PASSWORD'),

  mysql: {
    host: requiredEnv('MYSQL_HOST', '127.0.0.1'),
    port: parseInt(process.env.MYSQL_PORT || '3306', 10),
    user: requiredEnv('MYSQL_USER', 'root'),
    password: requiredEnv('MYSQL_PASSWORD'),
    database: requiredEnv('MYSQL_DATABASE', 'defaultdb'),
    connectionLimit: parseInt(process.env.MYSQL_CONNECTION_LIMIT || '10', 10),
    ssl: process.env.MYSQL_SSL === 'true',
  },
};
