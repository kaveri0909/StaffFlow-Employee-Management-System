export const swaggerDocument = {
  openapi: '3.0.0',
  info: {
    title: 'StaffFlow Employee Management System REST API',
    version: '1.0.0',
    description: 'Enterprise REST API specification for Employee Management, Authentication, and Department administration.',
    contact: {
      name: 'Engineering Team',
      email: 'support@staffflow.com',
    },
  },
  servers: [
    {
      url: '/api',
      description: 'API base path',
    },
  ],
  components: {
    securitySchemes: {
      bearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        description: 'Enter your JWT token obtained from /api/auth/login',
      },
    },
    schemas: {
      User: {
        type: 'object',
        properties: {
          id: { type: 'integer', example: 1 },
          username: { type: 'string', example: 'admin' },
          email: { type: 'string', example: 'admin@staffflow.com' },
          name: { type: 'string', example: 'System Administrator' },
          role: { type: 'string', enum: ['admin', 'hr_manager', 'viewer'], example: 'admin' },
        },
      },
      Department: {
        type: 'object',
        properties: {
          id: { type: 'integer', example: 1 },
          name: { type: 'string', example: 'Engineering' },
          description: { type: 'string', example: 'Software development & architecture' },
          manager_name: { type: 'string', example: 'Alex Chen' },
          budget: { type: 'number', example: 650000.0 },
          employee_count: { type: 'integer', example: 8 },
        },
      },
      Employee: {
        type: 'object',
        properties: {
          id: { type: 'integer', example: 1 },
          employee_id: { type: 'string', example: 'EMP-1001' },
          full_name: { type: 'string', example: 'Alexander Hayes' },
          email: { type: 'string', example: 'alexander.hayes@staffflow.com' },
          phone: { type: 'string', example: '+1 (555) 234-5678' },
          gender: { type: 'string', enum: ['Male', 'Female', 'Other', 'Prefer not to say'], example: 'Male' },
          date_of_birth: { type: 'string', format: 'date', example: '1988-04-14' },
          department_id: { type: 'integer', example: 1 },
          department_name: { type: 'string', example: 'Engineering' },
          designation: { type: 'string', example: 'Principal Software Engineer' },
          joining_date: { type: 'string', format: 'date', example: '2022-03-15' },
          salary: { type: 'number', example: 135000.0 },
          status: { type: 'string', enum: ['active', 'inactive', 'on_leave'], example: 'active' },
          address: { type: 'string', example: '742 Evergreen Terrace, Springfield, OR' },
        },
      },
      DashboardStats: {
        type: 'object',
        properties: {
          totalEmployees: { type: 'integer', example: 45 },
          activeEmployees: { type: 'integer', example: 40 },
          inactiveEmployees: { type: 'integer', example: 3 },
          onLeaveEmployees: { type: 'integer', example: 2 },
          totalDepartments: { type: 'integer', example: 6 },
          totalPayroll: { type: 'number', example: 4250000 },
          averageSalary: { type: 'number', example: 98000 },
        },
      },
    },
  },
  paths: {
    '/auth/login': {
      post: {
        summary: 'Admin & User login',
        tags: ['Authentication'],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['emailOrUsername', 'password'],
                properties: {
                  emailOrUsername: { type: 'string', example: 'admin@staffflow.com' },
                  password: { type: 'string', example: 'admin123' },
                },
              },
            },
          },
        },
        responses: {
          200: { description: 'Authenticated with JWT token' },
          401: { description: 'Invalid credentials' },
        },
      },
    },
    '/auth/logout': {
      post: {
        summary: 'Logout current session',
        tags: ['Authentication'],
        responses: {
          200: { description: 'Logged out successfully' },
        },
      },
    },
    '/auth/profile': {
      get: {
        summary: 'Get current user profile',
        tags: ['Authentication'],
        security: [{ bearerAuth: [] }],
        responses: {
          200: { description: 'Current user profile' },
          401: { description: 'Unauthorized' },
        },
      },
    },
    '/employees': {
      get: {
        summary: 'List employees with pagination, search, and filtering',
        tags: ['Employees'],
        security: [{ bearerAuth: [] }],
        parameters: [
          { name: 'search', in: 'query', schema: { type: 'string' }, description: 'Search term for name or email' },
          { name: 'department_id', in: 'query', schema: { type: 'integer' }, description: 'Filter by department ID' },
          { name: 'status', in: 'query', schema: { type: 'string', enum: ['active', 'inactive', 'on_leave', 'all'] } },
          { name: 'sortBy', in: 'query', schema: { type: 'string', enum: ['full_name', 'joining_date', 'salary', 'created_at'] } },
          { name: 'sortOrder', in: 'query', schema: { type: 'string', enum: ['asc', 'desc'] } },
          { name: 'page', in: 'query', schema: { type: 'integer', default: 1 } },
          { name: 'limit', in: 'query', schema: { type: 'integer', default: 10 } },
        ],
        responses: {
          200: { description: 'Paginated employee list' },
        },
      },
      post: {
        summary: 'Create a new employee',
        tags: ['Employees'],
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Employee' },
            },
          },
        },
        responses: {
          201: { description: 'Employee created' },
          409: { description: 'Email or ID conflict' },
        },
      },
    },
    '/employees/{id}': {
      get: {
        summary: 'Get employee details by ID',
        tags: ['Employees'],
        security: [{ bearerAuth: [] }],
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Employee profile found' },
          404: { description: 'Employee not found' },
        },
      },
      put: {
        summary: 'Update employee information',
        tags: ['Employees'],
        security: [{ bearerAuth: [] }],
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Employee' },
            },
          },
        },
        responses: {
          200: { description: 'Employee updated successfully' },
        },
      },
      delete: {
        summary: 'Delete employee record',
        tags: ['Employees'],
        security: [{ bearerAuth: [] }],
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Employee deleted' },
          404: { description: 'Employee not found' },
        },
      },
    },
    '/departments': {
      get: {
        summary: 'Get all departments with employee counts',
        tags: ['Departments'],
        security: [{ bearerAuth: [] }],
        responses: {
          200: { description: 'Department list' },
        },
      },
      post: {
        summary: 'Create a new department',
        tags: ['Departments'],
        security: [{ bearerAuth: [] }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Department' },
            },
          },
        },
        responses: {
          201: { description: 'Department created' },
        },
      },
    },
    '/departments/{id}': {
      get: {
        summary: 'Get department details and assigned employees',
        tags: ['Departments'],
        security: [{ bearerAuth: [] }],
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Department and employees retrieved' },
        },
      },
      put: {
        summary: 'Update department info',
        tags: ['Departments'],
        security: [{ bearerAuth: [] }],
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Department updated' },
        },
      },
      delete: {
        summary: 'Delete department (requires zero active employees)',
        tags: ['Departments'],
        security: [{ bearerAuth: [] }],
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Department deleted' },
          409: { description: 'Cannot delete: employees assigned to department' },
        },
      },
    },
    '/dashboard/stats': {
      get: {
        summary: 'Get dashboard metrics, salary analytics, and hiring trends',
        tags: ['Dashboard'],
        security: [{ bearerAuth: [] }],
        responses: {
          200: { description: 'Dashboard stats and charts' },
        },
      },
    },
  },
};
