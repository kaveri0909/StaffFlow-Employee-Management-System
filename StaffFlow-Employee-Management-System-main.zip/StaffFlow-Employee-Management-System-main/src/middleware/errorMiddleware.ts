import { Request, Response, NextFunction } from 'express';
import { sendError } from '../utils/apiResponse.ts';

export function errorHandler(
  err: any,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  console.error('[API Error]:', err);

  // MySQL Foreign key constraint violation error (ER_ROW_IS_REFERENCED_2 or ER_NO_REFERENCED_ROW_2)
  if (
    err.errno === 1451 ||
    err.errno === 1452 ||
    (err.message && err.message.toLowerCase().includes('foreign key constraint')) ||
    (err.message && err.message.includes('FOREIGN KEY constraint failed'))
  ) {
    sendError(res, 'Cannot delete or update record because related records depend on it.', 409);
    return;
  }

  // MySQL Unique constraint error (ER_DUP_ENTRY)
  if (
    err.errno === 1062 ||
    (err.message && err.message.includes('Duplicate entry')) ||
    (err.message && err.message.includes('UNIQUE constraint failed'))
  ) {
    sendError(res, 'A record with this identifier or email already exists in the database.', 409);
    return;
  }

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal server error occurred';

  sendError(res, message, statusCode);
}

export function notFoundHandler(req: Request, res: Response): void {
  sendError(res, `Endpoint not found: ${req.method} ${req.originalUrl}`, 404);
}
