import React from 'react';
import { X, Users, Mail, Phone, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Department, Employee } from '../types/index.ts';
import { formatCurrency, formatDate } from '../utils/formatters.ts';

interface DepartmentEmployeesModalProps {
  isOpen: boolean;
  onClose: () => void;
  department: (Department & { employees?: Employee[] }) | null;
}

export const DepartmentEmployeesModal: React.FC<DepartmentEmployeesModalProps> = ({
  isOpen,
  onClose,
  department,
}) => {
  if (!isOpen || !department) return null;

  const employees = department.employees || [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150 max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {department.name} - Assigned Team Members
              </h3>
              <p className="text-xs text-slate-500">
                {employees.length} employee{employees.length === 1 ? '' : 's'} assigned to this department
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of employees */}
        <div className="p-6 overflow-y-auto divide-y divide-slate-100 flex-1">
          {employees.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <p className="font-semibold text-slate-700">No employees assigned yet</p>
              <p className="text-xs text-slate-400 mt-1">
                You can assign employees to this department from the Employees directory.
              </p>
            </div>
          ) : (
            employees.map((emp) => (
              <div key={emp.id} className="py-3.5 first:pt-0 last:pb-0 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0">
                    {emp.full_name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900 text-sm">{emp.full_name}</span>
                      <span className="text-[11px] font-mono text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">
                        {emp.employee_id}
                      </span>
                    </div>
                    <div className="text-xs text-slate-500">{emp.designation}</div>
                  </div>
                </div>

                <div className="flex items-center gap-3 text-right">
                  <div className="hidden sm:block">
                    <div className="text-xs font-mono font-semibold text-slate-900">
                      {formatCurrency(emp.salary)}
                    </div>
                    <div className="text-[11px] text-slate-400">Joined {formatDate(emp.joining_date)}</div>
                  </div>
                  <Link
                    to={`/employees/${emp.id}`}
                    onClick={onClose}
                    className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                    title="View Employee Profile"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </Link>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-xl transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
