import React from 'react';
import { Link } from 'react-router-dom';
import { Eye, Edit3, Trash2, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { Employee, PaginationMeta } from '../types/index.ts';
import { formatCurrency, formatDate } from '../utils/formatters.ts';

interface EmployeeTableProps {
  employees: Employee[];
  pagination: PaginationMeta;
  isLoading: boolean;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
  onSort: (field: string) => void;
  onPageChange: (page: number) => void;
  onLimitChange: (limit: number) => void;
  onEdit: (employee: Employee) => void;
  onDelete: (employee: Employee) => void;
}

export const EmployeeTable: React.FC<EmployeeTableProps> = ({
  employees,
  pagination,
  isLoading,
  sortBy,
  sortOrder,
  onSort,
  onPageChange,
  onLimitChange,
  onEdit,
  onDelete,
}) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Active
          </span>
        );
      case 'inactive':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span>
            Inactive
          </span>
        );
      case 'on_leave':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-700 border border-amber-200/60">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            On Leave
          </span>
        );
      default:
        return <span className="text-xs text-slate-600">{status}</span>;
    }
  };

  const renderSortIcon = (field: string) => {
    if (sortBy !== field) {
      return <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />;
    }
    return sortOrder === 'asc' ? (
      <ArrowUp className="w-3.5 h-3.5 text-indigo-600" />
    ) : (
      <ArrowDown className="w-3.5 h-3.5 text-indigo-600" />
    );
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Table Container */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/80 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              <th
                onClick={() => onSort('employee_id')}
                className="py-3.5 px-4 cursor-pointer select-none group"
              >
                <div className="flex items-center gap-1.5">
                  <span>Emp ID</span>
                  {renderSortIcon('employee_id')}
                </div>
              </th>
              <th
                onClick={() => onSort('full_name')}
                className="py-3.5 px-4 cursor-pointer select-none group"
              >
                <div className="flex items-center gap-1.5">
                  <span>Employee Name</span>
                  {renderSortIcon('full_name')}
                </div>
              </th>
              <th className="py-3.5 px-4">Department & Role</th>
              <th
                onClick={() => onSort('joining_date')}
                className="py-3.5 px-4 cursor-pointer select-none group hidden md:table-cell"
              >
                <div className="flex items-center gap-1.5">
                  <span>Joined</span>
                  {renderSortIcon('joining_date')}
                </div>
              </th>
              <th
                onClick={() => onSort('salary')}
                className="py-3.5 px-4 cursor-pointer select-none group hidden lg:table-cell text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Salary</span>
                  {renderSortIcon('salary')}
                </div>
              </th>
              <th className="py-3.5 px-4 text-center">Status</th>
              <th className="py-3.5 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {isLoading ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-slate-500">
                  <div className="inline-flex items-center gap-2.5 text-sm font-medium">
                    <span className="w-5 h-5 border-2 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin" />
                    <span>Loading employee directory...</span>
                  </div>
                </td>
              </tr>
            ) : employees.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-12 text-center text-slate-500">
                  <div className="max-w-xs mx-auto space-y-1">
                    <p className="font-semibold text-slate-800">No employees found</p>
                    <p className="text-xs text-slate-500">
                      Try adjusting your search criteria or filter options.
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              employees.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-50/70 transition-colors group">
                  <td className="py-3.5 px-4 font-mono font-semibold text-xs text-indigo-600 whitespace-nowrap">
                    {emp.employee_id}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-slate-100 border border-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0">
                        {emp.full_name.charAt(0)}
                      </div>
                      <div>
                        <Link
                          to={`/employees/${emp.id}`}
                          className="font-semibold text-slate-900 hover:text-indigo-600 transition-colors block"
                        >
                          {emp.full_name}
                        </Link>
                        <span className="text-xs text-slate-500 block">{emp.email}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <div className="text-xs font-semibold text-slate-800">
                      {emp.department_name || 'Unassigned'}
                    </div>
                    <div className="text-xs text-slate-500">{emp.designation}</div>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap text-xs text-slate-600 hidden md:table-cell">
                    {formatDate(emp.joining_date)}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap text-xs font-mono font-semibold text-slate-900 text-right hidden lg:table-cell">
                    {formatCurrency(emp.salary)}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap text-center">
                    {getStatusBadge(emp.status)}
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap text-right">
                    <div className="inline-flex items-center gap-1">
                      <Link
                        to={`/employees/${emp.id}`}
                        title="View Full Profile"
                        className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </Link>
                      <button
                        onClick={() => onEdit(emp)}
                        title="Edit Employee"
                        className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-colors"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDelete(emp)}
                        title="Delete Employee"
                        className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="px-4 py-3 bg-slate-50/70 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-3">
          <span>
            Showing <span className="font-semibold text-slate-900">{employees.length}</span> of{' '}
            <span className="font-semibold text-slate-900">{pagination.total}</span> total employees
          </span>
          <div className="flex items-center gap-1.5 border-l border-slate-200 pl-3">
            <span>Per page:</span>
            <select
              value={pagination.limit}
              onChange={(e) => onLimitChange(Number(e.target.value))}
              className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700"
            >
              <option value="5">5</option>
              <option value="10">10</option>
              <option value="25">25</option>
              <option value="50">50</option>
            </select>
          </div>
        </div>

        {/* Page Nav */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onPageChange(pagination.page - 1)}
            disabled={!pagination.hasPrevPage}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            Previous
          </button>
          <span className="px-3 py-1 font-semibold text-slate-900">
            Page {pagination.page} of {pagination.totalPages}
          </span>
          <button
            onClick={() => onPageChange(pagination.page + 1)}
            disabled={!pagination.hasNextPage}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white font-semibold text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};
