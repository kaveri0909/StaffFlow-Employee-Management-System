import React from 'react';
import { formatCurrency } from '../utils/formatters.ts';

interface DepartmentDistItem {
  departmentId: number;
  departmentName: string;
  employeeCount: number;
  totalSalary: number;
  percentage: number;
}

interface JoiningTrendItem {
  period: string;
  count: number;
}

export const DepartmentDistributionChart: React.FC<{ data: DepartmentDistItem[] }> = ({ data }) => {
  if (!data || data.length === 0) {
    return <div className="text-sm text-slate-400 py-6 text-center">No department data available</div>;
  }

  const maxCount = Math.max(...data.map((d) => d.employeeCount), 1);

  return (
    <div className="space-y-4">
      {data.map((item) => {
        const barWidth = Math.max(6, Math.round((item.employeeCount / maxCount) * 100));
        return (
          <div key={item.departmentId} className="group">
            <div className="flex items-center justify-between text-xs font-medium mb-1">
              <span className="text-slate-800 font-semibold truncate max-w-[180px] sm:max-w-xs">
                {item.departmentName}
              </span>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 font-mono">{formatCurrency(item.totalSalary)}</span>
                <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[11px]">
                  {item.employeeCount} {item.employeeCount === 1 ? 'staff' : 'staff'} ({item.percentage}%)
                </span>
              </div>
            </div>
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-full transition-all duration-500 ease-out group-hover:from-indigo-600 group-hover:to-violet-600"
                style={{ width: `${barWidth}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

export const JoiningTrendsChart: React.FC<{ data: JoiningTrendItem[] }> = ({ data }) => {
  if (!data || data.length === 0) {
    return <div className="text-sm text-slate-400 py-6 text-center">No joining data recorded</div>;
  }

  const maxCount = Math.max(...data.map((d) => d.count), 4);
  const chartHeight = 160;
  const paddingX = 40;
  const paddingY = 24;

  const points = data.map((item, index) => {
    const x = paddingX + (index / Math.max(data.length - 1, 1)) * (400 - paddingX * 2);
    const y = chartHeight - paddingY - (item.count / maxCount) * (chartHeight - paddingY * 2);
    return { x, y, ...item };
  });

  const pathD = points.reduce((acc, pt, i) => {
    return i === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`;
  }, '');

  const areaD = points.length > 0
    ? `${pathD} L ${points[points.length - 1].x} ${chartHeight - paddingY} L ${points[0].x} ${chartHeight - paddingY} Z`
    : '';

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox="0 0 400 170" className="w-full h-44 overflow-visible" preserveAspectRatio="none">
        <defs>
          <linearGradient id="trendGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#6366f1" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0.0" />
          </linearGradient>
        </defs>

        {/* Grid lines */}
        {[0, 0.5, 1].map((ratio, i) => {
          const y = chartHeight - paddingY - ratio * (chartHeight - paddingY * 2);
          return (
            <line
              key={i}
              x1={paddingX - 10}
              y1={y}
              x2={400 - paddingX + 10}
              y2={y}
              stroke="#e2e8f0"
              strokeDasharray="4 4"
            />
          );
        })}

        {/* Area fill */}
        {areaD && <path d={areaD} fill="url(#trendGradient)" />}

        {/* Trend Line */}
        {pathD && (
          <path
            d={pathD}
            fill="none"
            stroke="#4f46e5"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        )}

        {/* Points and value tags */}
        {points.map((pt, i) => (
          <g key={i} className="group cursor-pointer">
            <circle
              cx={pt.x}
              cy={pt.y}
              r="4.5"
              className="fill-white stroke-indigo-600 stroke-[2.5] hover:r-6 transition-all"
            />
            {/* Value pill */}
            <text
              x={pt.x}
              y={pt.y - 10}
              textAnchor="middle"
              className="text-[10px] font-bold fill-slate-700"
            >
              {pt.count}
            </text>
            {/* Period label */}
            <text
              x={pt.x}
              y={chartHeight - 4}
              textAnchor="middle"
              className="text-[9px] font-medium fill-slate-400"
            >
              {pt.period}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
};
