import { Router } from 'express';
import { DepartmentController } from '../controllers/departmentController.ts';
import { authenticateJWT, authorizeRoles } from '../middleware/authMiddleware.ts';
import { validate } from '../middleware/validateMiddleware.ts';
import { createDepartmentSchema, updateDepartmentSchema } from '../validators/departmentValidators.ts';

const router = Router();

// All department routes require authentication
router.use(authenticateJWT);

// GET /api/departments
router.get('/', DepartmentController.getAll);

// GET /api/departments/:id
router.get('/:id', DepartmentController.getById);

// POST /api/departments (admin or hr_manager only)
router.post(
  '/',
  authorizeRoles('admin', 'hr_manager'),
  validate(createDepartmentSchema),
  DepartmentController.create
);

// PUT /api/departments/:id (admin or hr_manager only)
router.put(
  '/:id',
  authorizeRoles('admin', 'hr_manager'),
  validate(updateDepartmentSchema),
  DepartmentController.update
);

// DELETE /api/departments/:id (admin only)
router.delete(
  '/:id',
  authorizeRoles('admin'),
  DepartmentController.delete
);

export default router;
