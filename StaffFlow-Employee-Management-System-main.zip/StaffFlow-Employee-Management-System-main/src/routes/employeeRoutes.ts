import { Router } from 'express';
import { EmployeeController } from '../controllers/employeeController.ts';
import { authenticateJWT, authorizeRoles } from '../middleware/authMiddleware.ts';
import { validate } from '../middleware/validateMiddleware.ts';
import { createEmployeeSchema, updateEmployeeSchema, employeeQuerySchema } from '../validators/employeeValidators.ts';

const router = Router();

// All employee routes require authentication
router.use(authenticateJWT);

// GET /api/employees
router.get('/', validate(employeeQuerySchema, 'query'), EmployeeController.list);

// GET /api/employees/:id
router.get('/:id', EmployeeController.getById);

// POST /api/employees (admin or hr_manager)
router.post(
  '/',
  authorizeRoles('admin', 'hr_manager'),
  validate(createEmployeeSchema),
  EmployeeController.create
);

// PUT /api/employees/:id (admin or hr_manager)
router.put(
  '/:id',
  authorizeRoles('admin', 'hr_manager'),
  validate(updateEmployeeSchema),
  EmployeeController.update
);

// DELETE /api/employees/:id (admin only)
router.delete(
  '/:id',
  authorizeRoles('admin'),
  EmployeeController.delete
);

export default router;
