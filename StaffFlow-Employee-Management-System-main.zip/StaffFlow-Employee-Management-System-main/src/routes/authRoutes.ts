import { Router } from 'express';
import { AuthController } from '../controllers/authController.ts';
import { validate } from '../middleware/validateMiddleware.ts';
import { loginSchema, registerSchema } from '../validators/authValidators.ts';
import { authenticateJWT } from '../middleware/authMiddleware.ts';

const router = Router();

// POST /api/auth/login
router.post('/login', validate(loginSchema), AuthController.login);

// POST /api/auth/register
router.post('/register', validate(registerSchema), AuthController.register);

// POST /api/auth/logout
router.post('/logout', AuthController.logout);

// GET /api/auth/profile
router.get('/profile', authenticateJWT, AuthController.getProfile);

export default router;
