import { Router } from 'express';
import { DashboardController } from '../controllers/dashboardController.ts';
import { authenticateJWT, authorizeRoles } from '../middleware/authMiddleware.ts';

const router = Router();

// GET /api/dashboard/stats
router.get('/stats', authenticateJWT, DashboardController.getStats);

// POST /api/dashboard/reset
router.post('/reset', authenticateJWT, authorizeRoles('admin'), DashboardController.resetData);

export default router;
