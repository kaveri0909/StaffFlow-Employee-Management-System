import { Router, Request, Response } from 'express';
import { runAllTests } from '../tests/runTests.ts';
import { sendSuccess } from '../utils/apiResponse.ts';

const router = Router();

// GET /api/tests/run
router.get('/run', async (_req: Request, res: Response) => {
  const result = await runAllTests();
  sendSuccess(res, result, 'Test suite execution completed', 200);
});

export default router;
