import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import { readFileSync, existsSync } from 'fs';
import { resolve } from 'path';

dotenv.config();

export async function testAivenConnection() {
  const host = process.env.MYSQL_HOST;
  const port = parseInt(process.env.MYSQL_PORT || '24930', 10);
  const user = process.env.MYSQL_USER || 'avnadmin';
  const password = process.env.MYSQL_PASSWORD || '';
  const database = process.env.MYSQL_DATABASE || 'defaultdb';

  console.log('\n======================================================');
  console.log('       STAFFFLOW - AIVEN MYSQL DIAGNOSTIC');
  console.log('======================================================');
  console.log(` Target Host:       ${host || '[NOT SET - Missing MYSQL_HOST]'}`);
  console.log(` Target Port:       ${port}`);
  console.log(` Target User:       ${user}`);
  console.log(` Target Database:   ${database}`);
  console.log(` SSL Mode:          Enabled (rejectUnauthorized: true)`);
  console.log(` Password Provided: ${password ? 'YES (Hidden)' : 'NO (Empty)'}`);
  console.log('------------------------------------------------------');

  if (!host || host === 'localhost' || host === '127.0.0.1') {
    console.error(' [FAIL] MYSQL_HOST is not set to an Aiven remote hostname.');
    console.error(' Current value is localhost/127.0.0.1.');
    console.error(' Please provide your Aiven host (e.g. mysql-xxxx.aivencloud.com).');
    return { connected: false, reason: 'LOCAL_OR_UNSET_HOST' };
  }

  if (!password) {
    console.error(' [FAIL] MYSQL_PASSWORD is missing or empty.');
    console.error(' Aiven requires password authentication over TLS/SSL.');
    return { connected: false, reason: 'MISSING_PASSWORD' };
  }

  try {
    const caPath = resolve(process.cwd(), 'certs/ca.pem');

    if (!existsSync(caPath)) {
      throw new Error('Aiven CA certificate not found at certs/ca.pem');
    }

    const caCertificate = readFileSync(caPath);

    console.log(' CA Certificate:   FOUND');
    console.log(' SSL Verification: ENABLED');

    const conn = await mysql.createConnection({
      host,
      port,
      user,
      password,
      database,
      ssl: {
        ca: caCertificate,
        rejectUnauthorized: true,
      },
      connectTimeout: 10000,
    });

    console.log(' [SUCCESS] TLS/SSL Connection established to remote host!');

    const [infoRows] = await conn.query<any[]>(
      'SELECT VERSION() as version, DATABASE() as db, @@hostname as server_hostname, @@port as server_port'
    );
    const info = infoRows[0];
    console.log(` Server Version:    ${info.version}`);
    console.log(` Active Database:   ${info.db}`);
    console.log(` Remote @@hostname: ${info.server_hostname}`);
    console.log(` Remote @@port:     ${info.server_port}`);

    // Check tables
    const [tables] = await conn.query<any[]>('SHOW TABLES');
    const tableNames = tables.map((t) => Object.values(t)[0]);
    console.log(` Existing Tables:   ${tableNames.length > 0 ? tableNames.join(', ') : 'None (Empty Database)'}`);

    // Check counts if tables exist
    if (tableNames.includes('users') && tableNames.includes('departments') && tableNames.includes('employees')) {
      const [u] = await conn.query<any[]>('SELECT COUNT(*) as count FROM users');
      const [d] = await conn.query<any[]>('SELECT COUNT(*) as count FROM departments');
      const [e] = await conn.query<any[]>('SELECT COUNT(*) as count FROM employees');
      console.log(` Users Count:       ${u[0].count}`);
      console.log(` Departments Count: ${d[0].count}`);
      console.log(` Employees Count:   ${e[0].count}`);
    }

    await conn.end();
    return { connected: true, info };
  } catch (err: any) {
    console.error(` [ERROR] Failed to connect to Aiven: ${err.message}`);
    return { connected: false, error: err.message };
  }
}

if (process.argv[1] && process.argv[1].endsWith('test-aiven-connection.ts')) {
  testAivenConnection().then((res) => {
    console.log('======================================================\n');
    process.exit(res.connected ? 0 : 1);
  });
}
