import mysql from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';

dotenv.config();

export async function migrateToAiven() {
  const host = process.env.MYSQL_HOST;
  const port = parseInt(process.env.MYSQL_PORT || '24930', 10);
  const user = process.env.MYSQL_USER || 'avnadmin';
  const password = process.env.MYSQL_PASSWORD;
  const database = process.env.MYSQL_DATABASE || 'defaultdb';

  if (!host || host === 'localhost' || host === '127.0.0.1') {
    throw new Error('MYSQL_HOST must be set to your remote Aiven hostname (e.g., mysql-xxxx.aivencloud.com).');
  }

  if (!password) {
    throw new Error('MYSQL_PASSWORD is required to connect to Aiven MySQL.');
  }

  console.log(`[Aiven Migration] Connecting to ${host}:${port}/${database} as ${user} with SSL...`);

  const connection = await mysql.createConnection({
    host,
    port,
    user,
    password,
    database,
    ssl: { rejectUnauthorized: false },
    multipleStatements: true,
  });

  try {
    console.log('[Aiven Migration] Connected successfully. Creating schema...');

    // 1. Create tables in defaultdb
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        name VARCHAR(100) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'admin',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_users_email (email),
        INDEX idx_users_username (username)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

      CREATE TABLE IF NOT EXISTS departments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE,
        description TEXT,
        manager_name VARCHAR(100),
        budget DECIMAL(12, 2) DEFAULT 0.00,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_departments_name (name)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

      CREATE TABLE IF NOT EXISTS employees (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id VARCHAR(20) NOT NULL UNIQUE,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        phone VARCHAR(30) NOT NULL,
        gender VARCHAR(20) NOT NULL,
        date_of_birth DATE NOT NULL,
        department_id INT NOT NULL,
        designation VARCHAR(100) NOT NULL,
        joining_date DATE NOT NULL,
        salary DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        address TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_employees_department 
            FOREIGN KEY (department_id) 
            REFERENCES departments (id) 
            ON DELETE RESTRICT 
            ON UPDATE CASCADE,
        INDEX idx_employees_department_id (department_id),
        INDEX idx_employees_status (status),
        INDEX idx_employees_email (email),
        INDEX idx_employees_full_name (full_name),
        INDEX idx_employees_joining_date (joining_date)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);

    console.log('[Aiven Migration] Tables created. Populating seed dataset (3 users, 6 departments, 12 employees)...');

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync('admin123', salt);

    // Users
    await connection.query(
      `INSERT INTO users (id, username, email, password_hash, name, role) VALUES
       (1, 'admin', 'admin@staffflow.com', ?, 'System Administrator', 'admin'),
       (2, 'hrmanager', 'hr@staffflow.com', ?, 'Sarah Jenkins', 'hr_manager')
       ON DUPLICATE KEY UPDATE name=VALUES(name)`,
      [passwordHash, passwordHash]
    );

    // Departments
    await connection.query(`
      INSERT INTO departments (id, name, description, manager_name, budget) VALUES
      (1, 'Engineering', 'Software development, infrastructure, and technical architecture.', 'Alex Chen', 650000.00),
      (2, 'Human Resources', 'Talent acquisition, employee welfare, compensation, and onboarding.', 'Sarah Jenkins', 180000.00),
      (3, 'Product Management', 'Product vision, feature roadmaps, analytics, and UX research.', 'Marcus Brody', 290000.00),
      (4, 'Marketing & Sales', 'Brand strategy, enterprise sales, content marketing, and growth.', 'Elena Rostova', 340000.00),
      (5, 'Finance & Legal', 'Accounting, audit, financial planning, compliance, and governance.', 'David Kim', 210000.00),
      (6, 'Customer Support', 'Client success, technical customer care, and satisfaction SLA.', 'Priya Sharma', 140000.00)
      ON DUPLICATE KEY UPDATE name=VALUES(name)
    `);

    // Employees
    await connection.query(`
      INSERT INTO employees (id, employee_id, full_name, email, phone, gender, date_of_birth, department_id, designation, joining_date, salary, status, address) VALUES
      (1, 'EMP-1001', 'Alexander Hayes', 'alexander.hayes@staffflow.com', '+1 (555) 234-5678', 'Male', '1988-04-14', 1, 'Principal Software Engineer', '2022-03-15', 135000.00, 'active', '742 Evergreen Terrace, Springfield, OR'),
      (2, 'EMP-1002', 'Sophia Rodriguez', 'sophia.rodriguez@staffflow.com', '+1 (555) 345-6789', 'Female', '1992-09-21', 1, 'Senior Frontend Architect', '2022-06-01', 115000.00, 'active', '124 Conch Street, Pacific Grove, CA'),
      (3, 'EMP-1003', 'Liam O''Connor', 'liam.oconnor@staffflow.com', '+1 (555) 456-7890', 'Male', '1990-11-05', 1, 'DevOps & Cloud Engineer', '2023-01-10', 105000.00, 'active', '88 St. Marks Place, New York, NY'),
      (4, 'EMP-1004', 'Emily Watson', 'emily.watson@staffflow.com', '+1 (555) 567-8901', 'Female', '1994-02-18', 3, 'Lead Product Manager', '2022-08-20', 120000.00, 'active', '452 Pine Valley Rd, Austin, TX'),
      (5, 'EMP-1005', 'Marcus Vance', 'marcus.vance@staffflow.com', '+1 (555) 678-9012', 'Male', '1987-07-30', 2, 'Senior Talent Acquisition Lead', '2021-11-01', 88000.00, 'active', '303 Lincoln Way, Chicago, IL'),
      (6, 'EMP-1006', 'Aria Tanaka', 'aria.tanaka@staffflow.com', '+1 (555) 789-0123', 'Female', '1995-12-08', 4, 'Enterprise Account Executive', '2023-04-12', 95000.00, 'active', '910 Market Street, San Francisco, CA'),
      (7, 'EMP-1007', 'Nathanial Drake', 'nathanial.drake@staffflow.com', '+1 (555) 890-1234', 'Male', '1991-03-27', 4, 'Growth Marketing Director', '2022-02-15', 110000.00, 'active', '1802 Grand Ave, Seattle, WA'),
      (8, 'EMP-1008', 'Fatima Al-Mansoor', 'fatima.almansoor@staffflow.com', '+1 (555) 901-2345', 'Female', '1989-08-16', 5, 'Senior Financial Controller', '2021-09-01', 118000.00, 'active', '65 Commonwealth Ave, Boston, MA'),
      (9, 'EMP-1009', 'Jackson Reid', 'jackson.reid@staffflow.com', '+1 (555) 012-3456', 'Male', '1996-05-19', 1, 'Full Stack Engineer', '2023-09-01', 92000.00, 'active', '521 Boulder St, Denver, CO'),
      (10, 'EMP-1010', 'Chloe Bennett', 'chloe.bennett@staffflow.com', '+1 (555) 123-4560', 'Female', '1993-10-12', 6, 'Customer Success Manager', '2023-02-28', 78000.00, 'active', '44 Peachtree St, Atlanta, GA'),
      (11, 'EMP-1011', 'Devon Miller', 'devon.miller@staffflow.com', '+1 (555) 234-5671', 'Male', '1997-01-24', 6, 'Technical Support Specialist', '2024-01-15', 62000.00, 'inactive', '710 Broadway, Nashville, TN'),
      (12, 'EMP-1012', 'Hannah Zimmerman', 'hannah.zimmerman@staffflow.com', '+1 (555) 345-6782', 'Female', '1991-06-30', 3, 'Senior UX/UI Designer', '2023-07-10', 98000.00, 'on_leave', '110 Ocean Drive, Miami, FL')
      ON DUPLICATE KEY UPDATE full_name=VALUES(full_name)
    `);

    const [u] = await connection.query<any[]>('SELECT COUNT(*) as count FROM users');
    const [d] = await connection.query<any[]>('SELECT COUNT(*) as count FROM departments');
    const [e] = await connection.query<any[]>('SELECT COUNT(*) as count FROM employees');

    console.log('[Aiven Migration] Completed successfully:');
    console.log(` - Users:       ${u[0].count}`);
    console.log(` - Departments: ${d[0].count}`);
    console.log(` - Employees:   ${e[0].count}`);
  } finally {
    await connection.end();
  }
}

if (process.argv[1] && process.argv[1].endsWith('migrate-to-aiven.ts')) {
  migrateToAiven()
    .then(() => console.log('Migration to Aiven finished.'))
    .catch((err) => {
      console.error('Migration failed:', err.message);
      process.exit(1);
    });
}
