import { readFileSync } from 'node:fs';
import { pool } from '../src/config/db.ts';

async function main() {
  try {
    const sql = readFileSync('database/schema.sql', 'utf8');
    const statements = sql
      .split(';')
      .map(statement => statement.trim())
      .filter(statement => statement.length > 0);

    for (const statement of statements) {
      await pool.query(statement);
    }

    console.log('SUCCESS: Database schema applied.');
    const [tables] = await pool.query('SHOW TABLES');
    console.log('Tables:', tables);
  } catch (error) {
    console.error('Schema setup failed:', error);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main();
