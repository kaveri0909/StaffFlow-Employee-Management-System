import Database from 'better-sqlite3';
import mysql from 'mysql2/promise';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';

dotenv.config();

export interface MigrationSummary {
  sqliteFound: boolean;
  usersMigrated: number;
  departmentsMigrated: number;
  employeesMigrated: number;
  errors: string[];
}

export async function runMigration(): Promise<MigrationSummary> {
  const summary: MigrationSummary = {
    sqliteFound: false,
    usersMigrated: 0,
    departmentsMigrated: 0,
    employeesMigrated: 0,
    errors: [],
  };

  const sqlitePath = path.resolve(process.cwd(), 'database.sqlite');
  if (!fs.existsSync(sqlitePath)) {
    console.log('[Migration] No existing database.sqlite found. Skipping data import.');
    return summary;
  }

  summary.sqliteFound = true;
  console.log(`[Migration] Found source SQLite database at: ${sqlitePath}`);

  // Connect to SQLite (read-only)
  const sqlite = new Database(sqlitePath, { readonly: true });

  // Connect to MySQL
  const connection = await mysql.createConnection({
    host: process.env.MYSQL_HOST || '127.0.0.1',
    port: parseInt(process.env.MYSQL_PORT || '3306', 10),
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'employee_management',
  });

  try {
    // Disable foreign key checks during batch migration to preserve order and exact IDs
    await connection.query('SET FOREIGN_KEY_CHECKS = 0');

    // 1. Migrate Users
    try {
      const users = sqlite.prepare('SELECT * FROM users').all() as any[];
      console.log(`[Migration] Found ${users.length} user records in SQLite.`);
      for (const u of users) {
        await connection.query(
          `INSERT INTO users (id, username, email, password_hash, name, role, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE 
             username = VALUES(username),
             name = VALUES(name),
             role = VALUES(role),
             password_hash = VALUES(password_hash)`,
          [
            u.id,
            u.username,
            u.email,
            u.password_hash,
            u.name,
            u.role || 'admin',
            u.created_at || new Date(),
            u.updated_at || new Date(),
          ]
        );
        summary.usersMigrated++;
      }
    } catch (err: any) {
      summary.errors.push(`Users migration error: ${err.message}`);
    }

    // 2. Migrate Departments
    try {
      const departments = sqlite.prepare('SELECT * FROM departments').all() as any[];
      console.log(`[Migration] Found ${departments.length} department records in SQLite.`);
      for (const d of departments) {
        await connection.query(
          `INSERT INTO departments (id, name, description, manager_name, budget, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE 
             name = VALUES(name),
             description = VALUES(description),
             manager_name = VALUES(manager_name),
             budget = VALUES(budget)`,
          [
            d.id,
            d.name,
            d.description,
            d.manager_name,
            d.budget || 0,
            d.created_at || new Date(),
            d.updated_at || new Date(),
          ]
        );
        summary.departmentsMigrated++;
      }
    } catch (err: any) {
      summary.errors.push(`Departments migration error: ${err.message}`);
    }

    // 3. Migrate Employees
    try {
      const employees = sqlite.prepare('SELECT * FROM employees').all() as any[];
      console.log(`[Migration] Found ${employees.length} employee records in SQLite.`);
      for (const e of employees) {
        await connection.query(
          `INSERT INTO employees (
             id, employee_id, full_name, email, phone, gender, date_of_birth,
             department_id, designation, joining_date, salary, status, address,
             created_at, updated_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE
             full_name = VALUES(full_name),
             email = VALUES(email),
             phone = VALUES(phone),
             gender = VALUES(gender),
             date_of_birth = VALUES(date_of_birth),
             department_id = VALUES(department_id),
             designation = VALUES(designation),
             joining_date = VALUES(joining_date),
             salary = VALUES(salary),
             status = VALUES(status),
             address = VALUES(address)`,
          [
            e.id,
            e.employee_id,
            e.full_name,
            e.email,
            e.phone,
            e.gender,
            e.date_of_birth,
            e.department_id,
            e.designation,
            e.joining_date,
            e.salary || 0,
            e.status || 'active',
            e.address || null,
            e.created_at || new Date(),
            e.updated_at || new Date(),
          ]
        );
        summary.employeesMigrated++;
      }
    } catch (err: any) {
      summary.errors.push(`Employees migration error: ${err.message}`);
    }

    // Re-enable foreign key checks
    await connection.query('SET FOREIGN_KEY_CHECKS = 1');
  } finally {
    sqlite.close();
    await connection.end();
  }

  return summary;
}

// CLI runner
if (process.argv[1] && process.argv[1].endsWith('migrate-sqlite-to-mysql.ts')) {
  runMigration()
    .then((summary) => {
      console.log('\n=============================================');
      console.log('   SQLite to MySQL Data Migration Report');
      console.log('=============================================');
      console.log(` Source SQLite Found:     ${summary.sqliteFound ? 'YES' : 'NO'}`);
      console.log(` Users Migrated:          ${summary.usersMigrated}`);
      console.log(` Departments Migrated:    ${summary.departmentsMigrated}`);
      console.log(` Employees Migrated:      ${summary.employeesMigrated}`);
      if (summary.errors.length > 0) {
        console.log(` Errors encountered:      ${summary.errors.join('; ')}`);
      } else {
        console.log(' Status:                  100% SUCCESS');
      }
      console.log(' Original SQLite file:    PRESERVED (untouched)');
      console.log('=============================================\n');
    })
    .catch((err) => {
      console.error('Fatal migration error:', err);
      process.exit(1);
    });
}
