import { seedMySQL, pool, db } from '../src/config/db.ts';

async function main() {
  try {
    console.log('Starting StaffFlow database seeding...');

    await seedMySQL();

    const users = await db.query('SELECT id, username, email, role FROM users');
    const departments = await db.query('SELECT id, name FROM departments');
    const employees = await db.query('SELECT id, employee_id, full_name FROM employees');

    console.log('SUCCESS: Database seeding completed.');
    console.log('Users:', users.length);
    console.log('Departments:', departments.length);
    console.log('Employees:', employees.length);
    console.log('Seeded records:', { users, departments, employees });
  } catch (error) {
    console.error('Database seeding failed:', error);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main();
