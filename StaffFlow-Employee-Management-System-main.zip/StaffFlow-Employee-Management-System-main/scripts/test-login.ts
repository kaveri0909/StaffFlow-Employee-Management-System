const baseUrl = 'http://127.0.0.1:3000';

async function testLogin(
  label: string,
  emailOrUsername: string,
  password: string
) {
  const response = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ emailOrUsername, password }),
  });

  const result = await response.json();
  const user = result.data?.user;

  console.log(`${label}:`, response.status);
  console.log('Message:', result.message || result.error || 'No message');
  console.log('User:', user ? `${user.email} (${user.role})` : 'Not authenticated');
}

async function main() {
  const adminPassword = process.env.SEED_ADMIN_PASSWORD;
  const hrPassword = process.env.SEED_HR_PASSWORD;

  if (!adminPassword || !hrPassword) {
    throw new Error('Admin or HR password secret is missing.');
  }

  await testLogin('Admin login', 'admin@staffflow.com', adminPassword);
  await testLogin('HR login', 'hr@staffflow.com', hrPassword);
}

main().catch(error => {
  console.error('Login test failed:', error.message);
  process.exitCode = 1;
});
