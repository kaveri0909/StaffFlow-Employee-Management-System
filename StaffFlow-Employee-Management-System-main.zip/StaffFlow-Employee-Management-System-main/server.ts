import express from 'express';
import cors from 'cors';
import swaggerUi from 'swagger-ui-express';
import path from 'path';
import { fileURLToPath } from 'url';
import { swaggerDocument } from './src/config/swagger.ts';
import authRoutes from './src/routes/authRoutes.ts';
import employeeRoutes from './src/routes/employeeRoutes.ts';
import departmentRoutes from './src/routes/departmentRoutes.ts';
import dashboardRoutes from './src/routes/dashboardRoutes.ts';
import testRoutes from './src/routes/testRoutes.ts';
import { errorHandler } from './src/middleware/errorMiddleware.ts';
import { sendError } from './src/utils/apiResponse.ts';
import { db } from './src/config/db.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  // Middlewares
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Swagger OpenAPI Documentation
  app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument, {
    customSiteTitle: 'StaffFlow API Documentation',
  }));
  app.get('/api/docs.json', (_req, res) => {
    res.json(swaggerDocument);
  });

  // REST API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/employees', employeeRoutes);
  app.use('/api/departments', departmentRoutes);
  app.use('/api/dashboard', dashboardRoutes);
  app.use('/api/tests', testRoutes);

  // Health check endpoint with real MySQL connection status
  app.get('/api/health', async (_req, res) => {
    const dbStatus = await db.testConnection();
    res.json({
      status: dbStatus.connected ? 'ok' : 'degraded',
      timestamp: new Date().toISOString(),
      database: {
        driver: 'mysql2/promise',
        engine: 'MySQL',
        connected: dbStatus.connected,
        databaseName: dbStatus.database,
        serverVersion: dbStatus.version,
        error: dbStatus.error,
      },
    });
  });

  // Catch unmatched API requests
  app.all('/api/*', (req, res) => {
    sendError(res, `API route not found: ${req.method} ${req.originalUrl}`, 404);
  });

  // Centralized Error Handler
  app.use(errorHandler);

  // In production serve dist, in dev mount Vite dev server middlewares
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  // Verify MySQL on startup
  const dbStatus = await db.testConnection();
  if (dbStatus.connected) {
    console.log(`[MySQL] Successfully connected to database: ${dbStatus.database} (Version: ${dbStatus.version})`);
  } else {
    console.error(`[MySQL] Connection warning: ${dbStatus.error}`);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`StaffFlow server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
